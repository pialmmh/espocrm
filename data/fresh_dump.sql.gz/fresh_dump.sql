/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: espocrm
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(249) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sic_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_contact`
--

DROP TABLE IF EXISTS `account_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_contact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_inactive` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ACCOUNT_ID_CONTACT_ID` (`account_id`,`contact_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_contact`
--

LOCK TABLES `account_contact` WRITE;
/*!40000 ALTER TABLE `account_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_document`
--

DROP TABLE IF EXISTS `account_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_document` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ACCOUNT_ID_DOCUMENT_ID` (`account_id`,`document_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_document`
--

LOCK TABLES `account_document` WRITE;
/*!40000 ALTER TABLE `account_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_portal_user`
--

DROP TABLE IF EXISTS `account_portal_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_portal_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_ACCOUNT_ID` (`user_id`,`account_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_portal_user`
--

LOCK TABLES `account_portal_user` WRITE;
/*!40000 ALTER TABLE `account_portal_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_portal_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_target_list`
--

DROP TABLE IF EXISTS `account_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_target_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ACCOUNT_ID_TARGET_LIST_ID` (`account_id`,`target_list_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_target_list`
--

LOCK TABLES `account_target_list` WRITE;
/*!40000 ALTER TABLE `account_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `action_history_record`
--

DROP TABLE IF EXISTS `action_history_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `action_history_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `number` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `ip_address` varchar(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_log_record_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_TARGET` (`target_type`,`target_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_AUTH_TOKEN_ID` (`auth_token_id`),
  KEY `IDX_AUTH_LOG_RECORD_ID` (`auth_log_record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action_history_record`
--

LOCK TABLES `action_history_record` WRITE;
/*!40000 ALTER TABLE `action_history_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `action_history_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_country`
--

DROP TABLE IF EXISTS `address_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `address_country` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_preferred` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NAME` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_country`
--

LOCK TABLES `address_country` WRITE;
/*!40000 ALTER TABLE `address_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_log_record`
--

DROP TABLE IF EXISTS `app_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `number` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `exception_class` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line` int(11) DEFAULT NULL,
  `request_method` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_resource_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_LEVEL` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_log_record`
--

LOCK TABLES `app_log_record` WRITE;
/*!40000 ALTER TABLE `app_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_secret`
--

DROP TABLE IF EXISTS `app_secret`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_secret` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NAME_DELETE_ID` (`name`,`delete_id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_secret`
--

LOCK TABLES `app_secret` WRITE;
/*!40000 ALTER TABLE `app_secret` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_secret` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `array_value`
--

DROP TABLE IF EXISTS `array_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `array_value` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE_VALUE` (`entity_type`,`value`),
  KEY `IDX_ENTITY_VALUE` (`entity_type`,`entity_id`,`value`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `array_value`
--

LOCK TABLES `array_value` WRITE;
/*!40000 ALTER TABLE `array_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `array_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachment` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint(20) DEFAULT NULL,
  `field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_being_uploaded` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `role` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage_file_path` varchar(260) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `global` tinyint(1) NOT NULL DEFAULT 0,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PARENT` (`parent_type`,`parent_id`),
  KEY `IDX_RELATED` (`related_id`,`related_type`),
  KEY `IDX_SOURCE` (`source_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_log_record`
--

DROP TABLE IF EXISTS `auth_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_denied` tinyint(1) NOT NULL DEFAULT 0,
  `denial_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_time` double DEFAULT NULL,
  `request_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_method` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authentication_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_IP_ADDRESS` (`ip_address`),
  KEY `IDX_IP_ADDRESS_REQUEST_TIME` (`ip_address`,`request_time`),
  KEY `IDX_REQUEST_TIME` (`request_time`),
  KEY `IDX_USERNAME_IP_ADDRESS` (`username`,`ip_address`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_AUTH_TOKEN_ID` (`auth_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_log_record`
--

LOCK TABLES `auth_log_record` WRITE;
/*!40000 ALTER TABLE `auth_log_record` DISABLE KEYS */;
INSERT INTO `auth_log_record` VALUES
('69deb3450dd30c8bd',0,'admin','::1','2026-04-14 21:36:05',0,NULL,1776202564.9474,'http://localhost/api/v1/App/user','GET','Espo',NULL,'69deb215ad78dd7aa','69deb3450d3549185');
/*!40000 ALTER TABLE `auth_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_token`
--

DROP TABLE IF EXISTS `auth_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_token` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `token` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hash` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_access` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_TOKEN` (`token`,`deleted`),
  KEY `IDX_HASH` (`hash`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_token`
--

LOCK TABLES `auth_token` WRITE;
/*!40000 ALTER TABLE `auth_token` DISABLE KEYS */;
INSERT INTO `auth_token` VALUES
('69deb3450d3549185',0,'f1539a191a27348fe33acf0c999423c7','$2y$10$IJx7b85hLg.j3wefCWzZ3uJF.U/ihS8hJTbWK3QB9wc33i5nEoZhu','134c93d5fda1a9c49472dcf6b6e64d75','::1',1,'2026-04-14 22:14:10','2026-04-14 21:36:05','2026-04-14 22:14:10','69deb215ad78dd7aa',NULL);
/*!40000 ALTER TABLE `auth_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authentication_provider`
--

DROP TABLE IF EXISTS `authentication_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `authentication_provider` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_client_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_client_secret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_authorization_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_user_info_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_token_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_jwks_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_jwt_signature_algorithm_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '["RS256"]',
  `oidc_scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '["profile","email","phone"]',
  `oidc_create_user` tinyint(1) NOT NULL DEFAULT 0,
  `oidc_username_claim` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'sub',
  `oidc_sync` tinyint(1) NOT NULL DEFAULT 0,
  `oidc_logout_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_authorization_prompt` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_authorization_pkce` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication_provider`
--

LOCK TABLES `authentication_provider` WRITE;
/*!40000 ALTER TABLE `authentication_provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `authentication_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autofollow`
--

DROP TABLE IF EXISTS `autofollow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `autofollow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT 0,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE` (`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autofollow`
--

LOCK TABLES `autofollow` WRITE;
/*!40000 ALTER TABLE `autofollow` DISABLE KEYS */;
/*!40000 ALTER TABLE `autofollow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call`
--

DROP TABLE IF EXISTS `call`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `call` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planned',
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `direction` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Outbound',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_UID` (`uid`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call`
--

LOCK TABLES `call` WRITE;
/*!40000 ALTER TABLE `call` DISABLE KEYS */;
/*!40000 ALTER TABLE `call` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_contact`
--

DROP TABLE IF EXISTS `call_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_contact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `call_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CALL_ID_CONTACT_ID` (`call_id`,`contact_id`),
  KEY `IDX_CALL_ID` (`call_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_contact`
--

LOCK TABLES `call_contact` WRITE;
/*!40000 ALTER TABLE `call_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_lead`
--

DROP TABLE IF EXISTS `call_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_lead` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `call_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CALL_ID_LEAD_ID` (`call_id`,`lead_id`),
  KEY `IDX_CALL_ID` (`call_id`),
  KEY `IDX_LEAD_ID` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_lead`
--

LOCK TABLES `call_lead` WRITE;
/*!40000 ALTER TABLE `call_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_user`
--

DROP TABLE IF EXISTS `call_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_CALL_ID` (`user_id`,`call_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CALL_ID` (`call_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_user`
--

LOCK TABLES `call_user` WRITE;
/*!40000 ALTER TABLE `call_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planning',
  `type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Email',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `budget` double DEFAULT NULL,
  `mail_merge_only_with_address` tinyint(1) NOT NULL DEFAULT 1,
  `budget_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contacts_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leads_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accounts_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `users_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CONTACTS_TEMPLATE_ID` (`contacts_template_id`),
  KEY `IDX_LEADS_TEMPLATE_ID` (`leads_template_id`),
  KEY `IDX_ACCOUNTS_TEMPLATE_ID` (`accounts_template_id`),
  KEY `IDX_USERS_TEMPLATE_ID` (`users_template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign`
--

LOCK TABLES `campaign` WRITE;
/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_log_record`
--

DROP TABLE IF EXISTS `campaign_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `action` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_date` datetime DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `string_data` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `string_additional_data` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `application` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Espo',
  `created_at` datetime DEFAULT NULL,
  `is_test` tinyint(1) NOT NULL DEFAULT 0,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `queue_item_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ACTION_DATE` (`action_date`,`deleted`),
  KEY `IDX_ACTION` (`action`,`deleted`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_OBJECT` (`object_id`,`object_type`),
  KEY `IDX_QUEUE_ITEM_ID` (`queue_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_log_record`
--

LOCK TABLES `campaign_log_record` WRITE;
/*!40000 ALTER TABLE `campaign_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_target_list`
--

DROP TABLE IF EXISTS `campaign_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_target_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CAMPAIGN_ID_TARGET_LIST_ID` (`campaign_id`,`target_list_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_target_list`
--

LOCK TABLES `campaign_target_list` WRITE;
/*!40000 ALTER TABLE `campaign_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_target_list_excluding`
--

DROP TABLE IF EXISTS `campaign_target_list_excluding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_target_list_excluding` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CAMPAIGN_ID_TARGET_LIST_ID` (`campaign_id`,`target_list_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_target_list_excluding`
--

LOCK TABLES `campaign_target_list_excluding` WRITE;
/*!40000 ALTER TABLE `campaign_target_list_excluding` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_target_list_excluding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_tracking_url`
--

DROP TABLE IF EXISTS `campaign_tracking_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_tracking_url` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Redirect',
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_tracking_url`
--

LOCK TABLES `campaign_tracking_url` WRITE;
/*!40000 ALTER TABLE `campaign_tracking_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_tracking_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case`
--

DROP TABLE IF EXISTS `case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `number` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'New',
  `priority` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Normal',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_internal` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_LEAD_ID` (`lead_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`name`,`description`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case`
--

LOCK TABLES `case` WRITE;
/*!40000 ALTER TABLE `case` DISABLE KEYS */;
/*!40000 ALTER TABLE `case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_contact`
--

DROP TABLE IF EXISTS `case_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_contact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CASE_ID_CONTACT_ID` (`case_id`,`contact_id`),
  KEY `IDX_CASE_ID` (`case_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_contact`
--

LOCK TABLES `case_contact` WRITE;
/*!40000 ALTER TABLE `case_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `case_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_knowledge_base_article`
--

DROP TABLE IF EXISTS `case_knowledge_base_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_knowledge_base_article` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `case_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge_base_article_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CASE_ID_KNOWLEDGE_BASE_ARTICLE_ID` (`case_id`,`knowledge_base_article_id`),
  KEY `IDX_CASE_ID` (`case_id`),
  KEY `IDX_KNOWLEDGE_BASE_ARTICLE_ID` (`knowledge_base_article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_knowledge_base_article`
--

LOCK TABLES `case_knowledge_base_article` WRITE;
/*!40000 ALTER TABLE `case_knowledge_base_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `case_knowledge_base_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `do_not_call` tinyint(1) NOT NULL DEFAULT 0,
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_FIRST_NAME` (`first_name`,`deleted`),
  KEY `IDX_NAME` (`first_name`,`last_name`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_document`
--

DROP TABLE IF EXISTS `contact_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_document` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_DOCUMENT_ID` (`contact_id`,`document_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_document`
--

LOCK TABLES `contact_document` WRITE;
/*!40000 ALTER TABLE `contact_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_meeting`
--

DROP TABLE IF EXISTS `contact_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_meeting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_MEETING_ID` (`contact_id`,`meeting_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_MEETING_ID` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_meeting`
--

LOCK TABLES `contact_meeting` WRITE;
/*!40000 ALTER TABLE `contact_meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_opportunity`
--

DROP TABLE IF EXISTS `contact_opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_opportunity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_OPPORTUNITY_ID` (`contact_id`,`opportunity_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_OPPORTUNITY_ID` (`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_opportunity`
--

LOCK TABLES `contact_opportunity` WRITE;
/*!40000 ALTER TABLE `contact_opportunity` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_target_list`
--

DROP TABLE IF EXISTS `contact_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_target_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_TARGET_LIST_ID` (`contact_id`,`target_list_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_target_list`
--

LOCK TABLES `contact_target_list` WRITE;
/*!40000 ALTER TABLE `contact_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency` (
  `id` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES
('USD',1);
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_record`
--

DROP TABLE IF EXISTS `currency_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `code` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CODE_DELETE_ID` (`code`,`delete_id`),
  KEY `IDX_CODE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_record`
--

LOCK TABLES `currency_record` WRITE;
/*!40000 ALTER TABLE `currency_record` DISABLE KEYS */;
INSERT INTO `currency_record` VALUES
('69deb20cd33f4f211',0,'USD','Active','0');
/*!40000 ALTER TABLE `currency_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_record_rate`
--

DROP TABLE IF EXISTS `currency_record_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency_record_rate` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `base_code` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `record_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(20,8) DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_RECORD_ID_BASE_CODE_DATE` (`record_id`,`base_code`,`date`,`delete_id`),
  KEY `IDX_RECORD_ID` (`record_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_record_rate`
--

LOCK TABLES `currency_record_rate` WRITE;
/*!40000 ALTER TABLE `currency_record_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency_record_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_template`
--

DROP TABLE IF EXISTS `dashboard_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_template` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `layout` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashlets_options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_template`
--

LOCK TABLES `dashboard_template` WRITE;
/*!40000 ALTER TABLE `dashboard_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `file_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_FOLDER_ID` (`folder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_folder`
--

DROP TABLE IF EXISTS `document_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_folder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_folder`
--

LOCK TABLES `document_folder` WRITE;
/*!40000 ALTER TABLE `document_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_folder_path`
--

DROP TABLE IF EXISTS `document_folder_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_folder_path` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_folder_path`
--

LOCK TABLES `document_folder_path` WRITE;
/*!40000 ALTER TABLE `document_folder_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_folder_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_lead`
--

DROP TABLE IF EXISTS `document_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_lead` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_DOCUMENT_ID_LEAD_ID` (`document_id`,`lead_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`),
  KEY `IDX_LEAD_ID` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_lead`
--

LOCK TABLES `document_lead` WRITE;
/*!40000 ALTER TABLE `document_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_opportunity`
--

DROP TABLE IF EXISTS `document_opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_opportunity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_DOCUMENT_ID_OPPORTUNITY_ID` (`document_id`,`opportunity_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`),
  KEY `IDX_OPPORTUNITY_ID` (`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_opportunity`
--

LOCK TABLES `document_opportunity` WRITE;
/*!40000 ALTER TABLE `document_opportunity` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email`
--

DROP TABLE IF EXISTS `email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `from_string` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_string` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_name_map` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_replied` tinyint(1) NOT NULL DEFAULT 0,
  `message_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_id_internal` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_plain` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_html` tinyint(1) NOT NULL DEFAULT 1,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Archived',
  `has_attachment` tinyint(1) NOT NULL DEFAULT 0,
  `date_sent` datetime DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `send_at` datetime DEFAULT NULL,
  `is_auto_reply` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `is_system` tinyint(1) NOT NULL DEFAULT 0,
  `ics_contents` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ics_event_uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_status_folder` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_email_address_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replied_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_event_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_event_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_DATE_SENT` (`date_sent`,`deleted`),
  KEY `IDX_DATE_SENT_STATUS` (`date_sent`,`status`,`deleted`),
  KEY `IDX_MESSAGE_ID` (`message_id`),
  KEY `IDX_ICS_EVENT_UID` (`ics_event_uid`),
  KEY `IDX_GROUP_STATUS_FOLDER` (`group_status_folder`),
  KEY `IDX_FROM_EMAIL_ADDRESS_ID` (`from_email_address_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_SENT_BY_ID` (`sent_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_REPLIED_ID` (`replied_id`),
  KEY `IDX_CREATED_EVENT` (`created_event_id`,`created_event_type`),
  KEY `IDX_GROUP_FOLDER_ID` (`group_folder_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`name`,`body_plain`,`body`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email`
--

LOCK TABLES `email` WRITE;
/*!40000 ALTER TABLE `email` DISABLE KEYS */;
/*!40000 ALTER TABLE `email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_account`
--

DROP TABLE IF EXISTS `email_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_account` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `email_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` int(11) DEFAULT 993,
  `security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SSL',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monitored_folders` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '["INBOX"]',
  `sent_folder` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_map` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `store_sent_emails` tinyint(1) NOT NULL DEFAULT 0,
  `keep_fetched_emails_unread` tinyint(1) NOT NULL DEFAULT 0,
  `fetch_since` date DEFAULT NULL,
  `fetch_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `connected_at` datetime DEFAULT NULL,
  `use_imap` tinyint(1) NOT NULL DEFAULT 1,
  `use_smtp` tinyint(1) NOT NULL DEFAULT 0,
  `smtp_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` int(11) DEFAULT 587,
  `smtp_auth` tinyint(1) NOT NULL DEFAULT 1,
  `smtp_security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TLS',
  `smtp_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_auth_mechanism` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'login',
  `imap_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EMAIL_FOLDER_ID` (`email_folder_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_account`
--

LOCK TABLES `email_account` WRITE;
/*!40000 ALTER TABLE `email_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_address`
--

DROP TABLE IF EXISTS `email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_address` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `lower` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invalid` tinyint(1) NOT NULL DEFAULT 0,
  `opt_out` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `IDX_LOWER` (`lower`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_address`
--

LOCK TABLES `email_address` WRITE;
/*!40000 ALTER TABLE `email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_email_account`
--

DROP TABLE IF EXISTS `email_email_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_email_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_EMAIL_ACCOUNT_ID` (`email_id`,`email_account_id`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_EMAIL_ACCOUNT_ID` (`email_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_email_account`
--

LOCK TABLES `email_email_account` WRITE;
/*!40000 ALTER TABLE `email_email_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_email_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_email_address`
--

DROP TABLE IF EXISTS `email_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_email_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_address_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_type` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_EMAIL_ADDRESS_ID_ADDRESS_TYPE` (`email_id`,`email_address_id`,`address_type`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_EMAIL_ADDRESS_ID` (`email_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_email_address`
--

LOCK TABLES `email_email_address` WRITE;
/*!40000 ALTER TABLE `email_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_filter`
--

DROP TABLE IF EXISTS `email_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_filter` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_contains` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_contains_all` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_global` tinyint(1) NOT NULL DEFAULT 0,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Skip',
  `mark_as_read` tinyint(1) NOT NULL DEFAULT 0,
  `skip_notification` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_EMAIL_FOLDER_ID` (`email_folder_id`),
  KEY `IDX_GROUP_EMAIL_FOLDER_ID` (`group_email_folder_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_filter`
--

LOCK TABLES `email_filter` WRITE;
/*!40000 ALTER TABLE `email_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_folder`
--

DROP TABLE IF EXISTS `email_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_folder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `order` int(11) DEFAULT NULL,
  `skip_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_folder`
--

LOCK TABLES `email_folder` WRITE;
/*!40000 ALTER TABLE `email_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_inbound_email`
--

DROP TABLE IF EXISTS `email_inbound_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_inbound_email` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_INBOUND_EMAIL_ID` (`email_id`,`inbound_email_id`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_inbound_email`
--

LOCK TABLES `email_inbound_email` WRITE;
/*!40000 ALTER TABLE `email_inbound_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_inbound_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_queue_item`
--

DROP TABLE IF EXISTS `email_queue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_queue_item` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempt_count` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `email_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_test` tinyint(1) NOT NULL DEFAULT 0,
  `mass_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_SENT_AT` (`sent_at`),
  KEY `IDX_MASS_EMAIL_ID` (`mass_email_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_queue_item`
--

LOCK TABLES `email_queue_item` WRITE;
/*!40000 ALTER TABLE `email_queue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_queue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_template`
--

DROP TABLE IF EXISTS `email_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_template` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_html` tinyint(1) NOT NULL DEFAULT 1,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `one_off` tinyint(1) NOT NULL DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `category_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CATEGORY_ID` (`category_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_template`
--

LOCK TABLES `email_template` WRITE;
/*!40000 ALTER TABLE `email_template` DISABLE KEYS */;
INSERT INTO `email_template` VALUES
('69deb2255d0c92db1','Case-to-Email auto-reply',0,'Case has been created','<p>{Person.name},</p><p>Case \'{Case.name}\' has been created with number {Case.number} and assigned to {User.name}.</p>',1,'Active',0,NULL,'2026-04-14 21:31:17','2026-04-14 21:31:17',NULL,NULL,'system',NULL,1);
/*!40000 ALTER TABLE `email_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_template_category`
--

DROP TABLE IF EXISTS `email_template_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_template_category` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `order` int(11) DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_template_category`
--

LOCK TABLES `email_template_category` WRITE;
/*!40000 ALTER TABLE `email_template_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_template_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_template_category_path`
--

DROP TABLE IF EXISTS `email_template_category_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_template_category_path` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_template_category_path`
--

LOCK TABLES `email_template_category_path` WRITE;
/*!40000 ALTER TABLE `email_template_category_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_template_category_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_user`
--

DROP TABLE IF EXISTS `email_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `is_important` tinyint(1) DEFAULT 0,
  `in_trash` tinyint(1) DEFAULT 0,
  `in_archive` tinyint(1) DEFAULT 0,
  `folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_USER_ID` (`email_id`,`user_id`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_user`
--

LOCK TABLES `email_user` WRITE;
/*!40000 ALTER TABLE `email_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_collaborator`
--

DROP TABLE IF EXISTS `entity_collaborator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_collaborator` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_USER_ID_ENTITY_TYPE` (`entity_id`,`user_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_collaborator`
--

LOCK TABLES `entity_collaborator` WRITE;
/*!40000 ALTER TABLE `entity_collaborator` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_collaborator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_email_address`
--

DROP TABLE IF EXISTS `entity_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_email_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_address_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_EMAIL_ADDRESS_ID_ENTITY_TYPE` (`entity_id`,`email_address_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_EMAIL_ADDRESS_ID` (`email_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_email_address`
--

LOCK TABLES `entity_email_address` WRITE;
/*!40000 ALTER TABLE `entity_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_phone_number`
--

DROP TABLE IF EXISTS `entity_phone_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_phone_number` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_PHONE_NUMBER_ID_ENTITY_TYPE` (`entity_id`,`phone_number_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_PHONE_NUMBER_ID` (`phone_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_phone_number`
--

LOCK TABLES `entity_phone_number` WRITE;
/*!40000 ALTER TABLE `entity_phone_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_phone_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_team`
--

DROP TABLE IF EXISTS `entity_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_team` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_TEAM_ID_ENTITY_TYPE` (`entity_id`,`team_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_team`
--

LOCK TABLES `entity_team` WRITE;
/*!40000 ALTER TABLE `entity_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_user`
--

DROP TABLE IF EXISTS `entity_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_USER_ID_ENTITY_TYPE` (`entity_id`,`user_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_user`
--

LOCK TABLES `entity_user` WRITE;
/*!40000 ALTER TABLE `entity_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export`
--

DROP TABLE IF EXISTS `export`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `export` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `notify_on_finish` tinyint(1) NOT NULL DEFAULT 0,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_ATTACHMENT` (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export`
--

LOCK TABLES `export` WRITE;
/*!40000 ALTER TABLE `export` DISABLE KEYS */;
/*!40000 ALTER TABLE `export` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extension`
--

DROP TABLE IF EXISTS `extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `extension` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_status_message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_installed` tinyint(1) NOT NULL DEFAULT 0,
  `check_version_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_LICENSE_STATUS` (`license_status`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extension`
--

LOCK TABLES `extension` WRITE;
/*!40000 ALTER TABLE `extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_account`
--

DROP TABLE IF EXISTS `external_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_account` (
  `id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_account`
--

LOCK TABLES `external_account` WRITE;
/*!40000 ALTER TABLE `external_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `external_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_email_folder`
--

DROP TABLE IF EXISTS `group_email_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_email_folder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `order` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_email_folder`
--

LOCK TABLES `group_email_folder` WRITE;
/*!40000 ALTER TABLE `group_email_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_email_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_email_folder_team`
--

DROP TABLE IF EXISTS `group_email_folder_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_email_folder_team` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_GROUP_EMAIL_FOLDER_ID_TEAM_ID` (`group_email_folder_id`,`team_id`),
  KEY `IDX_GROUP_EMAIL_FOLDER_ID` (`group_email_folder_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_email_folder_team`
--

LOCK TABLES `group_email_folder_team` WRITE;
/*!40000 ALTER TABLE `group_email_folder_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_email_folder_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import`
--

DROP TABLE IF EXISTS `import`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `import` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_index` int(11) DEFAULT NULL,
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `file_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import`
--

LOCK TABLES `import` WRITE;
/*!40000 ALTER TABLE `import` DISABLE KEYS */;
/*!40000 ALTER TABLE `import` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_entity`
--

DROP TABLE IF EXISTS `import_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_entity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT 0,
  `is_imported` tinyint(1) NOT NULL DEFAULT 0,
  `is_updated` tinyint(1) NOT NULL DEFAULT 0,
  `is_duplicate` tinyint(1) NOT NULL DEFAULT 0,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `import_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_IMPORT` (`import_id`,`entity_type`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_IMPORT` (`import_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_entity`
--

LOCK TABLES `import_entity` WRITE;
/*!40000 ALTER TABLE `import_entity` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_error`
--

DROP TABLE IF EXISTS `import_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_error` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `row_index` int(11) DEFAULT NULL,
  `export_row_index` int(11) DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_failures` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `import_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ROW_INDEX` (`row_index`),
  KEY `IDX_IMPORT_ROW_INDEX` (`import_id`,`row_index`),
  KEY `IDX_IMPORT_ID` (`import_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_error`
--

LOCK TABLES `import_error` WRITE;
/*!40000 ALTER TABLE `import_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbound_email`
--

DROP TABLE IF EXISTS `inbound_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbound_email` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `email_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` int(11) DEFAULT 993,
  `security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SSL',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monitored_folders` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '["INBOX"]',
  `fetch_since` date DEFAULT NULL,
  `fetch_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `add_all_team_users` tinyint(1) NOT NULL DEFAULT 1,
  `sent_folder` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `store_sent_emails` tinyint(1) NOT NULL DEFAULT 0,
  `keep_fetched_emails_unread` tinyint(1) NOT NULL DEFAULT 0,
  `connected_at` datetime DEFAULT NULL,
  `exclude_from_reply` tinyint(1) NOT NULL DEFAULT 0,
  `use_imap` tinyint(1) NOT NULL DEFAULT 1,
  `use_smtp` tinyint(1) NOT NULL DEFAULT 0,
  `smtp_is_shared` tinyint(1) NOT NULL DEFAULT 0,
  `smtp_is_for_mass_email` tinyint(1) NOT NULL DEFAULT 0,
  `smtp_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` int(11) DEFAULT 587,
  `smtp_auth` tinyint(1) NOT NULL DEFAULT 1,
  `smtp_security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TLS',
  `smtp_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_auth_mechanism` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'login',
  `create_case` tinyint(1) NOT NULL DEFAULT 0,
  `case_distribution` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Direct-Assignment',
  `target_user_position` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply` tinyint(1) NOT NULL DEFAULT 0,
  `reply_from_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imap_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `assign_to_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_email_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASSIGN_TO_USER_ID` (`assign_to_user_id`),
  KEY `IDX_TEAM_ID` (`team_id`),
  KEY `IDX_REPLY_EMAIL_TEMPLATE_ID` (`reply_email_template_id`),
  KEY `IDX_GROUP_EMAIL_FOLDER_ID` (`group_email_folder_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbound_email`
--

LOCK TABLES `inbound_email` WRITE;
/*!40000 ALTER TABLE `inbound_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbound_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbound_email_team`
--

DROP TABLE IF EXISTS `inbound_email_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbound_email_team` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_INBOUND_EMAIL_ID_TEAM_ID` (`inbound_email_id`,`team_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbound_email_team`
--

LOCK TABLES `inbound_email_team` WRITE;
/*!40000 ALTER TABLE `inbound_email_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbound_email_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integration`
--

DROP TABLE IF EXISTS `integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `integration` (
  `id` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integration`
--

LOCK TABLES `integration` WRITE;
/*!40000 ALTER TABLE `integration` DISABLE KEYS */;
/*!40000 ALTER TABLE `integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `execute_time` datetime DEFAULT NULL,
  `number` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `queue` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_group` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `executed_at` datetime DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `attempts` int(11) DEFAULT NULL,
  `target_id` varchar(48) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_attempts` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `scheduled_job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_EXECUTE_TIME` (`status`,`execute_time`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_STATUS_SCHEDULED_JOB_ID` (`status`,`scheduled_job_id`),
  KEY `IDX_SCHEDULED_JOB_ID` (`scheduled_job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=258 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES
('69deb2256796076a8','Dummy',0,'Success','2026-04-14 21:31:17',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01',2964983,1,NULL,NULL,NULL,'2026-04-14 21:31:17','2026-04-14 21:33:01','69deb20ccfca76e52'),
('69deb28d8a83763b5','Submit Popup Reminders',0,'Success','2026-04-14 21:33:01',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01',2964983,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20ccb6fe02a5'),
('69deb28d8b7c6fe2d','Process Job Queue q0',0,'Success','2026-04-14 21:33:01',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01',2964983,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20ccd7429e61'),
('69deb28d8d0fc9ab2','Process Job Queue q1',0,'Success','2026-04-14 21:34:00',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01',2968038,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:34:01','69deb20cce715fc29'),
('69deb28d8d70a8592','Process Job Queue e0',0,'Success','2026-04-14 21:33:01',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01',2964983,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20ccf068606a'),
('69deb28d8ddae30f7','Dummy',0,'Pending','2026-04-15 00:01:00',6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20ccfca76e52'),
('69deb28d8e34f31cb','Check for New Version',0,'Pending','2026-04-15 05:15:00',7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20cd06ae2058'),
('69deb28d8eb2b5ffd','Check for New Versions of Installed Extensions',0,'Pending','2026-04-15 05:25:00',8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20cd1354293d'),
('69deb28d8f71e94c7','Sync Currency Rates',0,'Pending','2026-04-15 00:02:00',9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20cd1cfc824e'),
('69deb28d91359893f','Send Email Reminders',0,'Success','2026-04-14 21:34:00',10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01',2968038,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:34:01','69deb2255fe8dfb55'),
('69deb28d921e77fcf','Send Email Notifications',0,'Success','2026-04-14 21:34:00',11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01',2968038,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:34:01','69deb225605e2291c'),
('69deb28d9292e18b3','Clean-up',0,'Pending','2026-04-19 01:01:00',12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01','69deb22560e095554'),
('69deb28d9306a7031','Send Mass Emails',0,'Success','2026-04-14 21:50:00',13,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01',3017157,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:50:01','69deb22562da4c5df'),
('69deb28d937744937','Auth Token Control',0,'Success','2026-04-14 21:36:00',14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01',2974174,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:36:01','69deb2256424d2207'),
('69deb28d93e6a27aa','Control Knowledge Base Article Status',0,'Pending','2026-04-15 01:10:00',15,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:33:01','69deb22565663a129'),
('69deb28d945b93dad','Process Webhook Queue',0,'Success','2026-04-14 21:34:00',16,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01',2968038,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:34:01','69deb22566a130762'),
('69deb28d94c62938b','Send Scheduled Emails',0,'Success','2026-04-14 21:40:00',17,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02',2986939,1,NULL,NULL,NULL,'2026-04-14 21:33:01','2026-04-14 21:40:02','69deb225672074885'),
('69deb2c9c0cdc92bb','Submit Popup Reminders',0,'Success','2026-04-14 21:34:01',18,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01',2968038,1,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01','69deb20ccb6fe02a5'),
('69deb2c9c1a6c8bb1','Process Job Queue q0',0,'Success','2026-04-14 21:34:01',19,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01',2968038,1,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01','69deb20ccd7429e61'),
('69deb2c9c33fd91e6','Process Job Queue q1',0,'Success','2026-04-14 21:35:00',20,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:35:02','2026-04-14 21:35:02',2971233,1,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:35:02','69deb20cce715fc29'),
('69deb2c9c39971a98','Process Job Queue e0',0,'Success','2026-04-14 21:34:01',21,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01',2968038,1,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:34:01','69deb20ccf068606a'),
('69deb2c9c57d6eacd','Send Email Reminders',0,'Success','2026-04-14 21:36:00',22,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01',2974174,1,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:36:01','69deb2255fe8dfb55'),
('69deb2c9c6019f216','Send Email Notifications',0,'Success','2026-04-14 21:36:00',23,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01',2974174,1,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:36:01','69deb225605e2291c'),
('69deb2c9c6c473875','Process Webhook Queue',0,'Success','2026-04-14 21:36:00',24,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01',2974174,1,NULL,NULL,NULL,'2026-04-14 21:34:01','2026-04-14 21:36:01','69deb22566a130762'),
('69deb30605034e766','Submit Popup Reminders',0,'Success','2026-04-14 21:35:02',25,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:35:02','2026-04-14 21:35:02',2971233,1,NULL,NULL,NULL,'2026-04-14 21:35:02','2026-04-14 21:35:02','69deb20ccb6fe02a5'),
('69deb30605a23f580','Process Job Queue q0',0,'Success','2026-04-14 21:35:02',26,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:35:02','2026-04-14 21:35:02',2971233,1,NULL,NULL,NULL,'2026-04-14 21:35:02','2026-04-14 21:35:02','69deb20ccd7429e61'),
('69deb3060717f672f','Process Job Queue q1',0,'Success','2026-04-14 21:36:00',27,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01',2974174,1,NULL,NULL,NULL,'2026-04-14 21:35:02','2026-04-14 21:36:01','69deb20cce715fc29'),
('69deb3060779e9450','Process Job Queue e0',0,'Success','2026-04-14 21:35:02',28,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:35:02','2026-04-14 21:35:02',2971233,1,NULL,NULL,NULL,'2026-04-14 21:35:02','2026-04-14 21:35:02','69deb20ccf068606a'),
('69deb34137d5f20a9','Submit Popup Reminders',0,'Success','2026-04-14 21:36:01',29,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01',2974174,1,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01','69deb20ccb6fe02a5'),
('69deb34138527d030','Process Job Queue q0',0,'Success','2026-04-14 21:36:01',30,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01',2974174,1,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01','69deb20ccd7429e61'),
('69deb34138fe7dd88','Process Job Queue q1',0,'Success','2026-04-14 21:37:00',31,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:37:01','2026-04-14 21:37:01',2977209,1,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:37:01','69deb20cce715fc29'),
('69deb34139605fd53','Process Job Queue e0',0,'Success','2026-04-14 21:36:01',32,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01',2974174,1,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:36:01','69deb20ccf068606a'),
('69deb3413c0893ff2','Send Email Reminders',0,'Success','2026-04-14 21:38:00',33,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01',2980275,1,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:38:01','69deb2255fe8dfb55'),
('69deb3413c7892687','Send Email Notifications',0,'Success','2026-04-14 21:38:00',34,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01',2980275,1,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:38:01','69deb225605e2291c'),
('69deb3413ea0e9219','Auth Token Control',0,'Success','2026-04-14 21:42:00',35,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01',2992823,1,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:42:01','69deb2256424d2207'),
('69deb3413f38e5eab','Process Webhook Queue',0,'Success','2026-04-14 21:38:00',36,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01',2980275,1,NULL,NULL,NULL,'2026-04-14 21:36:01','2026-04-14 21:38:01','69deb22566a130762'),
('69deb37d6e280cc89','Submit Popup Reminders',0,'Success','2026-04-14 21:37:01',37,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:37:01','2026-04-14 21:37:01',2977209,1,NULL,NULL,NULL,'2026-04-14 21:37:01','2026-04-14 21:37:01','69deb20ccb6fe02a5'),
('69deb37d6f3966228','Process Job Queue q0',0,'Success','2026-04-14 21:37:01',38,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:37:01','2026-04-14 21:37:01',2977209,1,NULL,NULL,NULL,'2026-04-14 21:37:01','2026-04-14 21:37:01','69deb20ccd7429e61'),
('69deb37d6fed7f5b9','Process Job Queue q1',0,'Success','2026-04-14 21:38:00',39,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01',2980275,1,NULL,NULL,NULL,'2026-04-14 21:37:01','2026-04-14 21:38:01','69deb20cce715fc29'),
('69deb37d70565bdc5','Process Job Queue e0',0,'Success','2026-04-14 21:37:01',40,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:37:01','2026-04-14 21:37:01',2977209,1,NULL,NULL,NULL,'2026-04-14 21:37:01','2026-04-14 21:37:01','69deb20ccf068606a'),
('69deb3b996c8847db','Submit Popup Reminders',0,'Success','2026-04-14 21:38:01',41,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01',2980275,1,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01','69deb20ccb6fe02a5'),
('69deb3b9980720c98','Process Job Queue q0',0,'Success','2026-04-14 21:38:01',42,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01',2980275,1,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01','69deb20ccd7429e61'),
('69deb3b998f0b0458','Process Job Queue q1',0,'Success','2026-04-14 21:39:00',43,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:39:01','2026-04-14 21:39:01',2983403,1,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:39:01','69deb20cce715fc29'),
('69deb3b999453da99','Process Job Queue e0',0,'Success','2026-04-14 21:38:01',44,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01',2980275,1,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:38:01','69deb20ccf068606a'),
('69deb3b99ab2b8ee0','Send Email Reminders',0,'Success','2026-04-14 21:40:00',45,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02',2986939,1,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:40:02','69deb2255fe8dfb55'),
('69deb3b99b1647644','Send Email Notifications',0,'Success','2026-04-14 21:40:00',46,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02',2986939,1,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:40:02','69deb225605e2291c'),
('69deb3b99c550b281','Process Webhook Queue',0,'Success','2026-04-14 21:40:00',47,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02',2986939,1,NULL,NULL,NULL,'2026-04-14 21:38:01','2026-04-14 21:40:02','69deb22566a130762'),
('69deb3f5c9a85994f','Submit Popup Reminders',0,'Success','2026-04-14 21:39:01',48,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:39:01','2026-04-14 21:39:01',2983403,1,NULL,NULL,NULL,'2026-04-14 21:39:01','2026-04-14 21:39:01','69deb20ccb6fe02a5'),
('69deb3f5ca356c24e','Process Job Queue q0',0,'Success','2026-04-14 21:39:01',49,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:39:01','2026-04-14 21:39:01',2983403,1,NULL,NULL,NULL,'2026-04-14 21:39:01','2026-04-14 21:39:01','69deb20ccd7429e61'),
('69deb3f5cb10af287','Process Job Queue q1',0,'Success','2026-04-14 21:40:00',50,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02',2986939,1,NULL,NULL,NULL,'2026-04-14 21:39:01','2026-04-14 21:40:02','69deb20cce715fc29'),
('69deb3f5cb7b87ab5','Process Job Queue e0',0,'Success','2026-04-14 21:39:01',51,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:39:01','2026-04-14 21:39:01',2983403,1,NULL,NULL,NULL,'2026-04-14 21:39:01','2026-04-14 21:39:01','69deb20ccf068606a'),
('69deb432039285ddc','Submit Popup Reminders',0,'Success','2026-04-14 21:40:02',52,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02',2986939,1,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02','69deb20ccb6fe02a5'),
('69deb432048d7a40c','Process Job Queue q0',0,'Success','2026-04-14 21:40:02',53,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02',2986939,1,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02','69deb20ccd7429e61'),
('69deb43205656e533','Process Job Queue q1',0,'Success','2026-04-14 21:41:00',54,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:41:01','2026-04-14 21:41:01',2989883,1,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:41:01','69deb20cce715fc29'),
('69deb43205ef85101','Process Job Queue e0',0,'Success','2026-04-14 21:40:02',55,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02',2986939,1,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:40:02','69deb20ccf068606a'),
('69deb43207d09ac3f','Send Email Reminders',0,'Success','2026-04-14 21:42:00',56,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01',2992823,1,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:42:01','69deb2255fe8dfb55'),
('69deb4320849d692c','Send Email Notifications',0,'Success','2026-04-14 21:42:00',57,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01',2992823,1,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:42:01','69deb225605e2291c'),
('69deb432099579c5e','Process Webhook Queue',0,'Success','2026-04-14 21:42:00',58,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01',2992823,1,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:42:01','69deb22566a130762'),
('69deb4320a0e36e7e','Send Scheduled Emails',0,'Success','2026-04-14 21:50:00',59,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01',3017157,1,NULL,NULL,NULL,'2026-04-14 21:40:02','2026-04-14 21:50:01','69deb225672074885'),
('69deb46d4dae85074','Submit Popup Reminders',0,'Success','2026-04-14 21:41:01',60,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:41:01','2026-04-14 21:41:01',2989883,1,NULL,NULL,NULL,'2026-04-14 21:41:01','2026-04-14 21:41:01','69deb20ccb6fe02a5'),
('69deb46d4e5ab5bb0','Process Job Queue q0',0,'Success','2026-04-14 21:41:01',61,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:41:01','2026-04-14 21:41:01',2989883,1,NULL,NULL,NULL,'2026-04-14 21:41:01','2026-04-14 21:41:01','69deb20ccd7429e61'),
('69deb46d4fac213e7','Process Job Queue q1',0,'Success','2026-04-14 21:42:00',62,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01',2992823,1,NULL,NULL,NULL,'2026-04-14 21:41:01','2026-04-14 21:42:01','69deb20cce715fc29'),
('69deb46d5028c96fc','Process Job Queue e0',0,'Success','2026-04-14 21:41:01',63,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:41:01','2026-04-14 21:41:01',2989883,1,NULL,NULL,NULL,'2026-04-14 21:41:01','2026-04-14 21:41:01','69deb20ccf068606a'),
('69deb4a98276205bd','Submit Popup Reminders',0,'Success','2026-04-14 21:42:01',64,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01',2992823,1,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01','69deb20ccb6fe02a5'),
('69deb4a9832988bc3','Process Job Queue q0',0,'Success','2026-04-14 21:42:01',65,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01',2992823,1,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01','69deb20ccd7429e61'),
('69deb4a984337ae25','Process Job Queue q1',0,'Success','2026-04-14 21:43:00',66,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:43:01','2026-04-14 21:43:01',2995821,1,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:43:01','69deb20cce715fc29'),
('69deb4a984aa9f074','Process Job Queue e0',0,'Success','2026-04-14 21:42:01',67,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01',2992823,1,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:42:01','69deb20ccf068606a'),
('69deb4a9876e82999','Send Email Reminders',0,'Success','2026-04-14 21:44:00',68,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02',2998810,1,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:44:02','69deb2255fe8dfb55'),
('69deb4a987f68058e','Send Email Notifications',0,'Success','2026-04-14 21:44:00',69,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02',2998810,1,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:44:02','69deb225605e2291c'),
('69deb4a988aa97dfa','Auth Token Control',0,'Success','2026-04-14 21:48:00',70,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02',3011141,1,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:48:02','69deb2256424d2207'),
('69deb4a98935dead7','Process Webhook Queue',0,'Success','2026-04-14 21:44:00',71,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02',2998810,1,NULL,NULL,NULL,'2026-04-14 21:42:01','2026-04-14 21:44:02','69deb22566a130762'),
('69deb4e5bcf948cb6','Submit Popup Reminders',0,'Success','2026-04-14 21:43:01',72,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:43:01','2026-04-14 21:43:01',2995821,1,NULL,NULL,NULL,'2026-04-14 21:43:01','2026-04-14 21:43:01','69deb20ccb6fe02a5'),
('69deb4e5be34fc27c','Process Job Queue q0',0,'Success','2026-04-14 21:43:01',73,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:43:01','2026-04-14 21:43:01',2995821,1,NULL,NULL,NULL,'2026-04-14 21:43:01','2026-04-14 21:43:01','69deb20ccd7429e61'),
('69deb4e5beef84498','Process Job Queue q1',0,'Success','2026-04-14 21:44:00',74,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02',2998810,1,NULL,NULL,NULL,'2026-04-14 21:43:01','2026-04-14 21:44:02','69deb20cce715fc29'),
('69deb4e5c021e7246','Process Job Queue e0',0,'Success','2026-04-14 21:43:01',75,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:43:01','2026-04-14 21:43:01',2995821,1,NULL,NULL,NULL,'2026-04-14 21:43:01','2026-04-14 21:43:01','69deb20ccf068606a'),
('69deb522024e62160','Submit Popup Reminders',0,'Success','2026-04-14 21:44:02',76,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02',2998810,1,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02','69deb20ccb6fe02a5'),
('69deb52202f6e5c47','Process Job Queue q0',0,'Success','2026-04-14 21:44:02',77,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02',2998810,1,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02','69deb20ccd7429e61'),
('69deb52204da82160','Process Job Queue q1',0,'Success','2026-04-14 21:45:00',78,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:45:01','2026-04-14 21:45:01',3001750,1,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:45:01','69deb20cce715fc29'),
('69deb5220565bbe51','Process Job Queue e0',0,'Success','2026-04-14 21:44:02',79,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02',2998810,1,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:44:02','69deb20ccf068606a'),
('69deb5220867db410','Send Email Reminders',0,'Success','2026-04-14 21:46:00',80,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01',3005112,1,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:46:01','69deb2255fe8dfb55'),
('69deb52208f4da41d','Send Email Notifications',0,'Success','2026-04-14 21:46:00',81,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01',3005112,1,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:46:01','69deb225605e2291c'),
('69deb5220a0d8efe5','Process Webhook Queue',0,'Success','2026-04-14 21:46:00',82,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01',3005112,1,NULL,NULL,NULL,'2026-04-14 21:44:02','2026-04-14 21:46:01','69deb22566a130762'),
('69deb55d42416673c','Submit Popup Reminders',0,'Success','2026-04-14 21:45:01',83,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:45:01','2026-04-14 21:45:01',3001750,1,NULL,NULL,NULL,'2026-04-14 21:45:01','2026-04-14 21:45:01','69deb20ccb6fe02a5'),
('69deb55d42d9dc5f1','Process Job Queue q0',0,'Success','2026-04-14 21:45:01',84,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:45:01','2026-04-14 21:45:01',3001750,1,NULL,NULL,NULL,'2026-04-14 21:45:01','2026-04-14 21:45:01','69deb20ccd7429e61'),
('69deb55d44393e6e5','Process Job Queue q1',0,'Success','2026-04-14 21:46:00',85,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01',3005112,1,NULL,NULL,NULL,'2026-04-14 21:45:01','2026-04-14 21:46:01','69deb20cce715fc29'),
('69deb55d449a95c60','Process Job Queue e0',0,'Success','2026-04-14 21:45:01',86,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:45:01','2026-04-14 21:45:01',3001750,1,NULL,NULL,NULL,'2026-04-14 21:45:01','2026-04-14 21:45:01','69deb20ccf068606a'),
('69deb59988cdc220f','Submit Popup Reminders',0,'Success','2026-04-14 21:46:01',87,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01',3005112,1,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01','69deb20ccb6fe02a5'),
('69deb59989ec029b6','Process Job Queue q0',0,'Success','2026-04-14 21:46:01',88,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01',3005112,1,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01','69deb20ccd7429e61'),
('69deb5998c06e45c3','Process Job Queue q1',0,'Success','2026-04-14 21:47:00',89,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:47:01','2026-04-14 21:47:01',3008072,1,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:47:01','69deb20cce715fc29'),
('69deb5998cbc54448','Process Job Queue e0',0,'Success','2026-04-14 21:46:01',90,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01',3005112,1,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:46:01','69deb20ccf068606a'),
('69deb59990f79d7bc','Send Email Reminders',0,'Success','2026-04-14 21:48:00',91,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02',3011141,1,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:48:02','69deb2255fe8dfb55'),
('69deb59991a20223b','Send Email Notifications',0,'Success','2026-04-14 21:48:00',92,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02',3011141,1,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:48:02','69deb225605e2291c'),
('69deb599931db3d6b','Process Webhook Queue',0,'Success','2026-04-14 21:48:00',93,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02',3011141,1,NULL,NULL,NULL,'2026-04-14 21:46:01','2026-04-14 21:48:02','69deb22566a130762'),
('69deb5d5d17b231f7','Submit Popup Reminders',0,'Success','2026-04-14 21:47:01',94,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:47:01','2026-04-14 21:47:01',3008072,1,NULL,NULL,NULL,'2026-04-14 21:47:01','2026-04-14 21:47:01','69deb20ccb6fe02a5'),
('69deb5d5d1fab41b7','Process Job Queue q0',0,'Success','2026-04-14 21:47:01',95,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:47:01','2026-04-14 21:47:01',3008072,1,NULL,NULL,NULL,'2026-04-14 21:47:01','2026-04-14 21:47:01','69deb20ccd7429e61'),
('69deb5d5d2a45f9cf','Process Job Queue q1',0,'Success','2026-04-14 21:48:00',96,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02',3011141,1,NULL,NULL,NULL,'2026-04-14 21:47:01','2026-04-14 21:48:02','69deb20cce715fc29'),
('69deb5d5d371f22a3','Process Job Queue e0',0,'Success','2026-04-14 21:47:01',97,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:47:01','2026-04-14 21:47:01',3008072,1,NULL,NULL,NULL,'2026-04-14 21:47:01','2026-04-14 21:47:01','69deb20ccf068606a'),
('69deb61204d46f553','Submit Popup Reminders',0,'Success','2026-04-14 21:48:02',98,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02',3011141,1,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02','69deb20ccb6fe02a5'),
('69deb61205f12581b','Process Job Queue q0',0,'Success','2026-04-14 21:48:02',99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02',3011141,1,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02','69deb20ccd7429e61'),
('69deb61207c11d662','Process Job Queue q1',0,'Success','2026-04-14 21:49:00',100,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:49:01','2026-04-14 21:49:01',3014224,1,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:49:01','69deb20cce715fc29'),
('69deb61208b9718b5','Process Job Queue e0',0,'Success','2026-04-14 21:48:02',101,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02',3011141,1,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:48:02','69deb20ccf068606a'),
('69deb6120a306c047','Send Email Reminders',0,'Success','2026-04-14 21:50:00',102,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01',3017157,1,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:50:01','69deb2255fe8dfb55'),
('69deb6120a99f2299','Send Email Notifications',0,'Success','2026-04-14 21:50:00',103,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01',3017157,1,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:50:01','69deb225605e2291c'),
('69deb6120bdcd0066','Auth Token Control',0,'Success','2026-04-14 21:54:00',104,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01',3029419,1,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:54:01','69deb2256424d2207'),
('69deb6120c5b7d079','Process Webhook Queue',0,'Success','2026-04-14 21:50:00',105,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01',3017157,1,NULL,NULL,NULL,'2026-04-14 21:48:02','2026-04-14 21:50:01','69deb22566a130762'),
('69deb64d3d594a858','Submit Popup Reminders',0,'Success','2026-04-14 21:49:01',106,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:49:01','2026-04-14 21:49:01',3014224,1,NULL,NULL,NULL,'2026-04-14 21:49:01','2026-04-14 21:49:01','69deb20ccb6fe02a5'),
('69deb64d3e3b6bd4f','Process Job Queue q0',0,'Success','2026-04-14 21:49:01',107,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:49:01','2026-04-14 21:49:01',3014224,1,NULL,NULL,NULL,'2026-04-14 21:49:01','2026-04-14 21:49:01','69deb20ccd7429e61'),
('69deb64d3f03c9377','Process Job Queue q1',0,'Success','2026-04-14 21:50:00',108,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01',3017157,1,NULL,NULL,NULL,'2026-04-14 21:49:01','2026-04-14 21:50:01','69deb20cce715fc29'),
('69deb64d3f59e032d','Process Job Queue e0',0,'Success','2026-04-14 21:49:01',109,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:49:01','2026-04-14 21:49:01',3014224,1,NULL,NULL,NULL,'2026-04-14 21:49:01','2026-04-14 21:49:01','69deb20ccf068606a'),
('69deb689650f3000b','Submit Popup Reminders',0,'Success','2026-04-14 21:50:01',110,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01',3017157,1,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01','69deb20ccb6fe02a5'),
('69deb689658ea34a3','Process Job Queue q0',0,'Success','2026-04-14 21:50:01',111,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01',3017157,1,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01','69deb20ccd7429e61'),
('69deb689663c1e475','Process Job Queue q1',0,'Success','2026-04-14 21:51:00',112,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:51:01','2026-04-14 21:51:01',3020093,1,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:51:01','69deb20cce715fc29'),
('69deb689668ae87b9','Process Job Queue e0',0,'Success','2026-04-14 21:50:01',113,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01',3017157,1,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:50:01','69deb20ccf068606a'),
('69deb689680ae2e9b','Send Email Reminders',0,'Success','2026-04-14 21:52:00',114,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01',3023053,1,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:52:01','69deb2255fe8dfb55'),
('69deb6896903616a0','Send Email Notifications',0,'Success','2026-04-14 21:52:00',115,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01',3023053,1,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:52:01','69deb225605e2291c'),
('69deb689698168815','Send Mass Emails',0,'Success','2026-04-14 22:10:00',116,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01',3079314,1,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 22:10:01','69deb22562da4c5df'),
('69deb6896a1c2fbe3','Process Webhook Queue',0,'Success','2026-04-14 21:52:00',117,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01',3023053,1,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 21:52:01','69deb22566a130762'),
('69deb6896a89d2917','Send Scheduled Emails',0,'Success','2026-04-14 22:00:00',118,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01',3047717,1,NULL,NULL,NULL,'2026-04-14 21:50:01','2026-04-14 22:00:01','69deb225672074885'),
('69deb6c599697ae3e','Submit Popup Reminders',0,'Success','2026-04-14 21:51:01',119,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:51:01','2026-04-14 21:51:01',3020093,1,NULL,NULL,NULL,'2026-04-14 21:51:01','2026-04-14 21:51:01','69deb20ccb6fe02a5'),
('69deb6c59a9caa306','Process Job Queue q0',0,'Success','2026-04-14 21:51:01',120,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:51:01','2026-04-14 21:51:01',3020093,1,NULL,NULL,NULL,'2026-04-14 21:51:01','2026-04-14 21:51:01','69deb20ccd7429e61'),
('69deb6c59cdd6c773','Process Job Queue q1',0,'Success','2026-04-14 21:52:00',121,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01',3023053,1,NULL,NULL,NULL,'2026-04-14 21:51:01','2026-04-14 21:52:01','69deb20cce715fc29'),
('69deb6c59d47c42b7','Process Job Queue e0',0,'Success','2026-04-14 21:51:01',122,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:51:01','2026-04-14 21:51:01',3020093,1,NULL,NULL,NULL,'2026-04-14 21:51:01','2026-04-14 21:51:01','69deb20ccf068606a'),
('69deb701c74666a7c','Submit Popup Reminders',0,'Success','2026-04-14 21:52:01',123,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01',3023053,1,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01','69deb20ccb6fe02a5'),
('69deb701c8aea0e82','Process Job Queue q0',0,'Success','2026-04-14 21:52:01',124,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01',3023053,1,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01','69deb20ccd7429e61'),
('69deb701c963dfc9b','Process Job Queue q1',0,'Success','2026-04-14 21:53:00',125,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:53:02','2026-04-14 21:53:02',3026445,1,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:53:02','69deb20cce715fc29'),
('69deb701ca298546b','Process Job Queue e0',0,'Success','2026-04-14 21:52:01',126,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01',3023053,1,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:52:01','69deb20ccf068606a'),
('69deb701cb8ee6e72','Send Email Reminders',0,'Success','2026-04-14 21:54:00',127,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01',3029419,1,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:54:01','69deb2255fe8dfb55'),
('69deb701cbf7a3f7e','Send Email Notifications',0,'Success','2026-04-14 21:54:00',128,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01',3029419,1,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:54:01','69deb225605e2291c'),
('69deb701ccb0fd50d','Process Webhook Queue',0,'Success','2026-04-14 21:54:00',129,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01',3029419,1,NULL,NULL,NULL,'2026-04-14 21:52:01','2026-04-14 21:54:01','69deb22566a130762'),
('69deb73e0d24f40b0','Submit Popup Reminders',0,'Success','2026-04-14 21:53:02',130,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:53:02','2026-04-14 21:53:02',3026445,1,NULL,NULL,NULL,'2026-04-14 21:53:02','2026-04-14 21:53:02','69deb20ccb6fe02a5'),
('69deb73e0e0c51a4d','Process Job Queue q0',0,'Success','2026-04-14 21:53:02',131,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:53:02','2026-04-14 21:53:02',3026445,1,NULL,NULL,NULL,'2026-04-14 21:53:02','2026-04-14 21:53:02','69deb20ccd7429e61'),
('69deb73e0f27e836d','Process Job Queue q1',0,'Success','2026-04-14 21:54:00',132,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01',3029419,1,NULL,NULL,NULL,'2026-04-14 21:53:02','2026-04-14 21:54:01','69deb20cce715fc29'),
('69deb73e0fa1e32ce','Process Job Queue e0',0,'Success','2026-04-14 21:53:02',133,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:53:02','2026-04-14 21:53:02',3026445,1,NULL,NULL,NULL,'2026-04-14 21:53:02','2026-04-14 21:53:02','69deb20ccf068606a'),
('69deb779399919e6a','Submit Popup Reminders',0,'Success','2026-04-14 21:54:01',134,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01',3029419,1,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01','69deb20ccb6fe02a5'),
('69deb7793a53a92ce','Process Job Queue q0',0,'Success','2026-04-14 21:54:01',135,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01',3029419,1,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01','69deb20ccd7429e61'),
('69deb7793b46081c9','Process Job Queue q1',0,'Success','2026-04-14 21:55:00',136,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:55:01','2026-04-14 21:55:01',3032372,1,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:55:01','69deb20cce715fc29'),
('69deb7793ba0b71e3','Process Job Queue e0',0,'Success','2026-04-14 21:54:01',137,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01',3029419,1,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:54:01','69deb20ccf068606a'),
('69deb7793db34be7d','Send Email Reminders',0,'Success','2026-04-14 21:56:00',138,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01',3035336,1,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:56:01','69deb2255fe8dfb55'),
('69deb7793e1de34ff','Send Email Notifications',0,'Success','2026-04-14 21:56:00',139,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01',3035336,1,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:56:01','69deb225605e2291c'),
('69deb7793ebe04c3a','Auth Token Control',0,'Success','2026-04-14 22:00:00',140,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01',3047717,1,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 22:00:01','69deb2256424d2207'),
('69deb7793f429a0d1','Process Webhook Queue',0,'Success','2026-04-14 21:56:00',141,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01',3035336,1,NULL,NULL,NULL,'2026-04-14 21:54:01','2026-04-14 21:56:01','69deb22566a130762'),
('69deb7b56f72c93a4','Submit Popup Reminders',0,'Success','2026-04-14 21:55:01',142,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:55:01','2026-04-14 21:55:01',3032372,1,NULL,NULL,NULL,'2026-04-14 21:55:01','2026-04-14 21:55:01','69deb20ccb6fe02a5'),
('69deb7b56feddf7f7','Process Job Queue q0',0,'Success','2026-04-14 21:55:01',143,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:55:01','2026-04-14 21:55:01',3032372,1,NULL,NULL,NULL,'2026-04-14 21:55:01','2026-04-14 21:55:01','69deb20ccd7429e61'),
('69deb7b571270af72','Process Job Queue q1',0,'Success','2026-04-14 21:56:00',144,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01',3035336,1,NULL,NULL,NULL,'2026-04-14 21:55:01','2026-04-14 21:56:01','69deb20cce715fc29'),
('69deb7b5718312514','Process Job Queue e0',0,'Success','2026-04-14 21:55:01',145,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:55:01','2026-04-14 21:55:01',3032372,1,NULL,NULL,NULL,'2026-04-14 21:55:01','2026-04-14 21:55:01','69deb20ccf068606a'),
('69deb7f19749bb8c6','Submit Popup Reminders',0,'Success','2026-04-14 21:56:01',146,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01',3035336,1,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01','69deb20ccb6fe02a5'),
('69deb7f19873e07d5','Process Job Queue q0',0,'Success','2026-04-14 21:56:01',147,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01',3035336,1,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01','69deb20ccd7429e61'),
('69deb7f199301e40b','Process Job Queue q1',0,'Success','2026-04-14 21:57:00',148,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:57:01','2026-04-14 21:57:01',3038250,1,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:57:01','69deb20cce715fc29'),
('69deb7f19a0c2ad46','Process Job Queue e0',0,'Success','2026-04-14 21:56:01',149,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01',3035336,1,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:56:01','69deb20ccf068606a'),
('69deb7f19bf85ec54','Send Email Reminders',0,'Success','2026-04-14 21:58:00',150,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:58:02',3041690,1,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:58:02','69deb2255fe8dfb55'),
('69deb7f19c687c030','Send Email Notifications',0,'Success','2026-04-14 21:58:00',151,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:58:02',3041690,1,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:58:02','69deb225605e2291c'),
('69deb7f19d06db6a0','Process Webhook Queue',0,'Success','2026-04-14 21:58:00',152,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:58:02',3041690,1,NULL,NULL,NULL,'2026-04-14 21:56:01','2026-04-14 21:58:02','69deb22566a130762'),
('69deb82dca602cc9b','Submit Popup Reminders',0,'Success','2026-04-14 21:57:01',153,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:57:01','2026-04-14 21:57:01',3038250,1,NULL,NULL,NULL,'2026-04-14 21:57:01','2026-04-14 21:57:01','69deb20ccb6fe02a5'),
('69deb82dcb3f3db51','Process Job Queue q0',0,'Success','2026-04-14 21:57:01',154,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:57:01','2026-04-14 21:57:01',3038250,1,NULL,NULL,NULL,'2026-04-14 21:57:01','2026-04-14 21:57:01','69deb20ccd7429e61'),
('69deb82dcbec6ce80','Process Job Queue q1',0,'Success','2026-04-14 21:58:00',155,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:58:02',3041690,1,NULL,NULL,NULL,'2026-04-14 21:57:01','2026-04-14 21:58:02','69deb20cce715fc29'),
('69deb82dcc4029296','Process Job Queue e0',0,'Success','2026-04-14 21:57:01',156,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:57:01','2026-04-14 21:57:01',3038250,1,NULL,NULL,NULL,'2026-04-14 21:57:01','2026-04-14 21:57:01','69deb20ccf068606a'),
('69deb869f3b379933','Submit Popup Reminders',0,'Success','2026-04-14 21:58:01',157,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:58:02',3041690,1,NULL,NULL,NULL,'2026-04-14 21:58:01','2026-04-14 21:58:02','69deb20ccb6fe02a5'),
('69deb86a00117f977','Process Job Queue q0',0,'Success','2026-04-14 21:58:02',158,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:58:02',3041690,1,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:58:02','69deb20ccd7429e61'),
('69deb86a00b8c834a','Process Job Queue q1',0,'Success','2026-04-14 21:59:00',159,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:59:01','2026-04-14 21:59:01',3044646,1,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:59:01','69deb20cce715fc29'),
('69deb86a0119053b6','Process Job Queue e0',0,'Success','2026-04-14 21:58:02',160,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:58:02',3041690,1,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 21:58:02','69deb20ccf068606a'),
('69deb86a028319b0a','Send Email Reminders',0,'Success','2026-04-14 22:00:00',161,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01',3047717,1,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 22:00:01','69deb2255fe8dfb55'),
('69deb86a03a99b754','Send Email Notifications',0,'Success','2026-04-14 22:00:00',162,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01',3047717,1,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 22:00:01','69deb225605e2291c'),
('69deb86a046b167ed','Process Webhook Queue',0,'Success','2026-04-14 22:00:00',163,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01',3047717,1,NULL,NULL,NULL,'2026-04-14 21:58:02','2026-04-14 22:00:01','69deb22566a130762'),
('69deb8a5376ff140b','Submit Popup Reminders',0,'Success','2026-04-14 21:59:01',164,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:59:01','2026-04-14 21:59:01',3044646,1,NULL,NULL,NULL,'2026-04-14 21:59:01','2026-04-14 21:59:01','69deb20ccb6fe02a5'),
('69deb8a537fc7d8a3','Process Job Queue q0',0,'Success','2026-04-14 21:59:01',165,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:59:01','2026-04-14 21:59:01',3044646,1,NULL,NULL,NULL,'2026-04-14 21:59:01','2026-04-14 21:59:01','69deb20ccd7429e61'),
('69deb8a538ab09943','Process Job Queue q1',0,'Success','2026-04-14 22:00:00',166,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01',3047717,1,NULL,NULL,NULL,'2026-04-14 21:59:01','2026-04-14 22:00:01','69deb20cce715fc29'),
('69deb8a5390442950','Process Job Queue e0',0,'Success','2026-04-14 21:59:01',167,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 21:59:01','2026-04-14 21:59:01',3044646,1,NULL,NULL,NULL,'2026-04-14 21:59:01','2026-04-14 21:59:01','69deb20ccf068606a'),
('69deb8e16174830e7','Submit Popup Reminders',0,'Success','2026-04-14 22:00:01',168,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01',3047717,1,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01','69deb20ccb6fe02a5'),
('69deb8e1628f9f412','Process Job Queue q0',0,'Success','2026-04-14 22:00:01',169,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01',3047717,1,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01','69deb20ccd7429e61'),
('69deb8e1634225e79','Process Job Queue q1',0,'Success','2026-04-14 22:01:00',170,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:01:01','2026-04-14 22:01:01',3050809,1,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:01:01','69deb20cce715fc29'),
('69deb8e1639d8bebf','Process Job Queue e0',0,'Success','2026-04-14 22:00:01',171,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01',3047717,1,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:00:01','69deb20ccf068606a'),
('69deb8e164ea987c6','Send Email Reminders',0,'Success','2026-04-14 22:02:00',172,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01',3053840,1,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:02:01','69deb2255fe8dfb55'),
('69deb8e1655e1f510','Send Email Notifications',0,'Success','2026-04-14 22:02:00',173,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01',3053840,1,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:02:01','69deb225605e2291c'),
('69deb8e165f515d4b','Auth Token Control',0,'Success','2026-04-14 22:06:00',174,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01',3066553,1,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:06:01','69deb2256424d2207'),
('69deb8e166ef7f1eb','Process Webhook Queue',0,'Success','2026-04-14 22:02:00',175,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01',3053840,1,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:02:01','69deb22566a130762'),
('69deb8e16752235e1','Send Scheduled Emails',0,'Success','2026-04-14 22:10:00',176,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01',3079314,1,NULL,NULL,NULL,'2026-04-14 22:00:01','2026-04-14 22:10:01','69deb225672074885'),
('69deb91d9bf0a35fb','Submit Popup Reminders',0,'Success','2026-04-14 22:01:01',177,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:01:01','2026-04-14 22:01:01',3050809,1,NULL,NULL,NULL,'2026-04-14 22:01:01','2026-04-14 22:01:01','69deb20ccb6fe02a5'),
('69deb91d9c716dca4','Process Job Queue q0',0,'Success','2026-04-14 22:01:01',178,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:01:01','2026-04-14 22:01:01',3050809,1,NULL,NULL,NULL,'2026-04-14 22:01:01','2026-04-14 22:01:01','69deb20ccd7429e61'),
('69deb91d9da8768cb','Process Job Queue q1',0,'Success','2026-04-14 22:02:00',179,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01',3053840,1,NULL,NULL,NULL,'2026-04-14 22:01:01','2026-04-14 22:02:01','69deb20cce715fc29'),
('69deb91d9e44491be','Process Job Queue e0',0,'Success','2026-04-14 22:01:01',180,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:01:01','2026-04-14 22:01:01',3050809,1,NULL,NULL,NULL,'2026-04-14 22:01:01','2026-04-14 22:01:01','69deb20ccf068606a'),
('69deb959c102ab61c','Submit Popup Reminders',0,'Success','2026-04-14 22:02:01',181,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01',3053840,1,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01','69deb20ccb6fe02a5'),
('69deb959c237e7a97','Process Job Queue q0',0,'Success','2026-04-14 22:02:01',182,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01',3053840,1,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01','69deb20ccd7429e61'),
('69deb959c2f402293','Process Job Queue q1',0,'Success','2026-04-14 22:03:00',183,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:03:02','2026-04-14 22:03:02',3057435,1,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:03:02','69deb20cce715fc29'),
('69deb959c3d49a03a','Process Job Queue e0',0,'Success','2026-04-14 22:02:01',184,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01',3053840,1,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:02:01','69deb20ccf068606a'),
('69deb959c56a577b1','Send Email Reminders',0,'Success','2026-04-14 22:04:00',185,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01',3060466,1,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:04:01','69deb2255fe8dfb55'),
('69deb959c5cbf7c57','Send Email Notifications',0,'Success','2026-04-14 22:04:00',186,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01',3060466,1,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:04:01','69deb225605e2291c'),
('69deb959c69959651','Process Webhook Queue',0,'Success','2026-04-14 22:04:00',187,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01',3060466,1,NULL,NULL,NULL,'2026-04-14 22:02:01','2026-04-14 22:04:01','69deb22566a130762'),
('69deb9960947f77b1','Submit Popup Reminders',0,'Success','2026-04-14 22:03:02',188,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:03:02','2026-04-14 22:03:02',3057435,1,NULL,NULL,NULL,'2026-04-14 22:03:02','2026-04-14 22:03:02','69deb20ccb6fe02a5'),
('69deb9960a1e08f56','Process Job Queue q0',0,'Success','2026-04-14 22:03:02',189,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:03:02','2026-04-14 22:03:02',3057435,1,NULL,NULL,NULL,'2026-04-14 22:03:02','2026-04-14 22:03:02','69deb20ccd7429e61'),
('69deb9960b60cc485','Process Job Queue q1',0,'Success','2026-04-14 22:04:00',190,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01',3060466,1,NULL,NULL,NULL,'2026-04-14 22:03:02','2026-04-14 22:04:01','69deb20cce715fc29'),
('69deb9960be47b898','Process Job Queue e0',0,'Success','2026-04-14 22:03:02',191,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:03:02','2026-04-14 22:03:02',3057435,1,NULL,NULL,NULL,'2026-04-14 22:03:02','2026-04-14 22:03:02','69deb20ccf068606a'),
('69deb9d143da65a04','Submit Popup Reminders',0,'Success','2026-04-14 22:04:01',192,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01',3060466,1,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01','69deb20ccb6fe02a5'),
('69deb9d1446c9db78','Process Job Queue q0',0,'Success','2026-04-14 22:04:01',193,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01',3060466,1,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01','69deb20ccd7429e61'),
('69deb9d1452136206','Process Job Queue q1',0,'Success','2026-04-14 22:05:00',194,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:05:01','2026-04-14 22:05:01',3063571,1,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:05:01','69deb20cce715fc29'),
('69deb9d145733ca81','Process Job Queue e0',0,'Success','2026-04-14 22:04:01',195,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01',3060466,1,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:04:01','69deb20ccf068606a'),
('69deb9d1476631ec0','Send Email Reminders',0,'Success','2026-04-14 22:06:00',196,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01',3066553,1,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:06:01','69deb2255fe8dfb55'),
('69deb9d14878ea3ed','Send Email Notifications',0,'Success','2026-04-14 22:06:00',197,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01',3066553,1,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:06:01','69deb225605e2291c'),
('69deb9d14940405fc','Process Webhook Queue',0,'Success','2026-04-14 22:06:00',198,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01',3066553,1,NULL,NULL,NULL,'2026-04-14 22:04:01','2026-04-14 22:06:01','69deb22566a130762'),
('69deba0d7f7029eee','Submit Popup Reminders',0,'Success','2026-04-14 22:05:01',199,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:05:01','2026-04-14 22:05:01',3063571,1,NULL,NULL,NULL,'2026-04-14 22:05:01','2026-04-14 22:05:01','69deb20ccb6fe02a5'),
('69deba0d802a81d84','Process Job Queue q0',0,'Success','2026-04-14 22:05:01',200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:05:01','2026-04-14 22:05:01',3063571,1,NULL,NULL,NULL,'2026-04-14 22:05:01','2026-04-14 22:05:01','69deb20ccd7429e61'),
('69deba0d81592be29','Process Job Queue q1',0,'Success','2026-04-14 22:06:00',201,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01',3066553,1,NULL,NULL,NULL,'2026-04-14 22:05:01','2026-04-14 22:06:01','69deb20cce715fc29'),
('69deba0d81cde1987','Process Job Queue e0',0,'Success','2026-04-14 22:05:01',202,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:05:01','2026-04-14 22:05:01',3063571,1,NULL,NULL,NULL,'2026-04-14 22:05:01','2026-04-14 22:05:01','69deb20ccf068606a'),
('69deba49ba17d8cd9','Submit Popup Reminders',0,'Success','2026-04-14 22:06:01',203,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01',3066553,1,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01','69deb20ccb6fe02a5'),
('69deba49bb0551ebf','Process Job Queue q0',0,'Success','2026-04-14 22:06:01',204,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01',3066553,1,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01','69deb20ccd7429e61'),
('69deba49bc62a8645','Process Job Queue q1',0,'Success','2026-04-14 22:07:00',205,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:07:02','2026-04-14 22:07:02',3069645,1,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:07:02','69deb20cce715fc29'),
('69deba49bcd99d150','Process Job Queue e0',0,'Success','2026-04-14 22:06:01',206,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01',3066553,1,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:06:01','69deb20ccf068606a'),
('69deba49c0ac8e76a','Send Email Reminders',0,'Success','2026-04-14 22:08:00',207,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01',3072734,1,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:08:01','69deb2255fe8dfb55'),
('69deba49c13ecdf95','Send Email Notifications',0,'Success','2026-04-14 22:08:00',208,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01',3072734,1,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:08:01','69deb225605e2291c'),
('69deba49c3e839c47','Auth Token Control',0,'Success','2026-04-14 22:12:00',209,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01',3085212,1,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:12:01','69deb2256424d2207'),
('69deba49c59a8e4c1','Process Webhook Queue',0,'Success','2026-04-14 22:08:00',210,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01',3072734,1,NULL,NULL,NULL,'2026-04-14 22:06:01','2026-04-14 22:08:01','69deb22566a130762'),
('69deba8615b821456','Submit Popup Reminders',0,'Success','2026-04-14 22:07:02',211,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:07:02','2026-04-14 22:07:02',3069645,1,NULL,NULL,NULL,'2026-04-14 22:07:02','2026-04-14 22:07:02','69deb20ccb6fe02a5'),
('69deba8617650b2bc','Process Job Queue q0',0,'Success','2026-04-14 22:07:02',212,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:07:02','2026-04-14 22:07:02',3069645,1,NULL,NULL,NULL,'2026-04-14 22:07:02','2026-04-14 22:07:02','69deb20ccd7429e61'),
('69deba861874404d6','Process Job Queue q1',0,'Success','2026-04-14 22:08:00',213,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01',3072734,1,NULL,NULL,NULL,'2026-04-14 22:07:02','2026-04-14 22:08:01','69deb20cce715fc29'),
('69deba8618e6d1f72','Process Job Queue e0',0,'Success','2026-04-14 22:07:02',214,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:07:02','2026-04-14 22:07:02',3069645,1,NULL,NULL,NULL,'2026-04-14 22:07:02','2026-04-14 22:07:02','69deb20ccf068606a'),
('69debac14ac15fd5f','Submit Popup Reminders',0,'Success','2026-04-14 22:08:01',215,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01',3072734,1,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01','69deb20ccb6fe02a5'),
('69debac14bb0d349a','Process Job Queue q0',0,'Success','2026-04-14 22:08:01',216,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01',3072734,1,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01','69deb20ccd7429e61'),
('69debac14d1b49b35','Process Job Queue q1',0,'Success','2026-04-14 22:09:00',217,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:09:01','2026-04-14 22:09:01',3075852,1,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:09:01','69deb20cce715fc29'),
('69debac14d6ea0b77','Process Job Queue e0',0,'Success','2026-04-14 22:08:01',218,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01',3072734,1,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:08:01','69deb20ccf068606a'),
('69debac14ef91d717','Send Email Reminders',0,'Success','2026-04-14 22:10:00',219,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01',3079314,1,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:10:01','69deb2255fe8dfb55'),
('69debac14f5bf8b80','Send Email Notifications',0,'Success','2026-04-14 22:10:00',220,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01',3079314,1,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:10:01','69deb225605e2291c'),
('69debac1504bcdeb4','Process Webhook Queue',0,'Success','2026-04-14 22:10:00',221,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01',3079314,1,NULL,NULL,NULL,'2026-04-14 22:08:01','2026-04-14 22:10:01','69deb22566a130762'),
('69debafd843088c23','Submit Popup Reminders',0,'Success','2026-04-14 22:09:01',222,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:09:01','2026-04-14 22:09:01',3075852,1,NULL,NULL,NULL,'2026-04-14 22:09:01','2026-04-14 22:09:01','69deb20ccb6fe02a5'),
('69debafd8550e6d87','Process Job Queue q0',0,'Success','2026-04-14 22:09:01',223,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:09:01','2026-04-14 22:09:01',3075852,1,NULL,NULL,NULL,'2026-04-14 22:09:01','2026-04-14 22:09:01','69deb20ccd7429e61'),
('69debafd8693f4a28','Process Job Queue q1',0,'Success','2026-04-14 22:10:00',224,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01',3079314,1,NULL,NULL,NULL,'2026-04-14 22:09:01','2026-04-14 22:10:01','69deb20cce715fc29'),
('69debafd86f029645','Process Job Queue e0',0,'Success','2026-04-14 22:09:01',225,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:09:01','2026-04-14 22:09:01',3075852,1,NULL,NULL,NULL,'2026-04-14 22:09:01','2026-04-14 22:09:01','69deb20ccf068606a'),
('69debb39b6124006a','Submit Popup Reminders',0,'Success','2026-04-14 22:10:01',226,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01',3079314,1,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01','69deb20ccb6fe02a5'),
('69debb39b6d36da3a','Process Job Queue q0',0,'Success','2026-04-14 22:10:01',227,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01',3079314,1,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01','69deb20ccd7429e61'),
('69debb39b8c0b8c67','Process Job Queue q1',0,'Success','2026-04-14 22:11:00',228,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:11:02','2026-04-14 22:11:02',3082267,1,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:11:02','69deb20cce715fc29'),
('69debb39b936161b9','Process Job Queue e0',0,'Success','2026-04-14 22:10:01',229,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01',3079314,1,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01','69deb20ccf068606a'),
('69debb39bbc23381e','Send Email Reminders',0,'Success','2026-04-14 22:12:00',230,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01',3085212,1,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:12:01','69deb2255fe8dfb55'),
('69debb39bc5c3db76','Send Email Notifications',0,'Success','2026-04-14 22:12:00',231,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01',3085212,1,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:12:01','69deb225605e2291c'),
('69debb39bcf411102','Send Mass Emails',0,'Pending','2026-04-14 22:30:00',232,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01','69deb22562da4c5df'),
('69debb39bddba62f6','Process Webhook Queue',0,'Success','2026-04-14 22:12:00',233,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01',3085212,1,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:12:01','69deb22566a130762'),
('69debb39be8282f9f','Send Scheduled Emails',0,'Pending','2026-04-14 22:20:00',234,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 22:10:01','2026-04-14 22:10:01','69deb225672074885'),
('69debb760c6bed659','Submit Popup Reminders',0,'Success','2026-04-14 22:11:02',235,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:11:02','2026-04-14 22:11:02',3082267,1,NULL,NULL,NULL,'2026-04-14 22:11:02','2026-04-14 22:11:02','69deb20ccb6fe02a5'),
('69debb760d07bc43a','Process Job Queue q0',0,'Success','2026-04-14 22:11:02',236,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:11:02','2026-04-14 22:11:02',3082267,1,NULL,NULL,NULL,'2026-04-14 22:11:02','2026-04-14 22:11:02','69deb20ccd7429e61'),
('69debb760e0ef0dc1','Process Job Queue q1',0,'Success','2026-04-14 22:12:00',237,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01',3085212,1,NULL,NULL,NULL,'2026-04-14 22:11:02','2026-04-14 22:12:01','69deb20cce715fc29'),
('69debb760e7782ae1','Process Job Queue e0',0,'Success','2026-04-14 22:11:02',238,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:11:02','2026-04-14 22:11:02',3082267,1,NULL,NULL,NULL,'2026-04-14 22:11:02','2026-04-14 22:11:02','69deb20ccf068606a'),
('69debbb14424dd388','Submit Popup Reminders',0,'Success','2026-04-14 22:12:01',239,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01',3085212,1,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01','69deb20ccb6fe02a5'),
('69debbb1456d742ec','Process Job Queue q0',0,'Success','2026-04-14 22:12:01',240,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01',3085212,1,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01','69deb20ccd7429e61'),
('69debbb146fe8874a','Process Job Queue q1',0,'Success','2026-04-14 22:13:00',241,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:13:01','2026-04-14 22:13:01',3088332,1,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:13:01','69deb20cce715fc29'),
('69debbb14844bb602','Process Job Queue e0',0,'Success','2026-04-14 22:12:01',242,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01',3085212,1,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01','69deb20ccf068606a'),
('69debbb14d5672432','Send Email Reminders',0,'Success','2026-04-14 22:14:00',243,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01',3091484,1,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:14:01','69deb2255fe8dfb55'),
('69debbb14df651080','Send Email Notifications',0,'Success','2026-04-14 22:14:00',244,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01',3091484,1,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:14:01','69deb225605e2291c'),
('69debbb14f145c915','Auth Token Control',0,'Pending','2026-04-14 22:18:00',245,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:12:01','69deb2256424d2207'),
('69debbb14fd1843ec','Process Webhook Queue',0,'Success','2026-04-14 22:14:00',246,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01',3091484,1,NULL,NULL,NULL,'2026-04-14 22:12:01','2026-04-14 22:14:01','69deb22566a130762'),
('69debbed89ccff3be','Submit Popup Reminders',0,'Success','2026-04-14 22:13:01',247,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:13:01','2026-04-14 22:13:01',3088332,1,NULL,NULL,NULL,'2026-04-14 22:13:01','2026-04-14 22:13:01','69deb20ccb6fe02a5'),
('69debbed8a9418beb','Process Job Queue q0',0,'Success','2026-04-14 22:13:01',248,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:13:01','2026-04-14 22:13:01',3088332,1,NULL,NULL,NULL,'2026-04-14 22:13:01','2026-04-14 22:13:01','69deb20ccd7429e61'),
('69debbed8b859636c','Process Job Queue q1',0,'Success','2026-04-14 22:14:00',249,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01',3091484,1,NULL,NULL,NULL,'2026-04-14 22:13:01','2026-04-14 22:14:01','69deb20cce715fc29'),
('69debbed8be113b43','Process Job Queue e0',0,'Success','2026-04-14 22:13:01',250,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:13:01','2026-04-14 22:13:01',3088332,1,NULL,NULL,NULL,'2026-04-14 22:13:01','2026-04-14 22:13:01','69deb20ccf068606a'),
('69debc29b6b6fe316','Submit Popup Reminders',0,'Success','2026-04-14 22:14:01',251,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01',3091484,1,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01','69deb20ccb6fe02a5'),
('69debc29b72f741bf','Process Job Queue q0',0,'Success','2026-04-14 22:14:01',252,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01',3091484,1,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01','69deb20ccd7429e61'),
('69debc29b7e59b308','Process Job Queue q1',0,'Pending','2026-04-14 22:15:00',253,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01','69deb20cce715fc29'),
('69debc29b847fb172','Process Job Queue e0',0,'Success','2026-04-14 22:14:01',254,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01',3091484,1,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01','69deb20ccf068606a'),
('69debc29ba58c0b71','Send Email Reminders',0,'Pending','2026-04-14 22:16:00',255,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01','69deb2255fe8dfb55'),
('69debc29bac1d5440','Send Email Notifications',0,'Pending','2026-04-14 22:16:00',256,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01','69deb225605e2291c'),
('69debc29bb74715c6','Process Webhook Queue',0,'Pending','2026-04-14 22:16:00',257,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-04-14 22:14:01','2026-04-14 22:14:01','69deb22566a130762');
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kanban_order`
--

DROP TABLE IF EXISTS `kanban_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kanban_order` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `order` smallint(6) DEFAULT NULL,
  `group` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_USER_ID` (`entity_type`,`entity_id`,`user_id`),
  KEY `IDX_ENTITY_TYPE` (`entity_type`),
  KEY `IDX_ENTITY_TYPE_USER_ID` (`entity_type`,`user_id`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kanban_order`
--

LOCK TABLES `kanban_order` WRITE;
/*!40000 ALTER TABLE `kanban_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `kanban_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_article`
--

DROP TABLE IF EXISTS `knowledge_base_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_article` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Draft',
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Article',
  `publish_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_plain` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`name`,`body_plain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_article`
--

LOCK TABLES `knowledge_base_article` WRITE;
/*!40000 ALTER TABLE `knowledge_base_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_article_knowledge_base_category`
--

DROP TABLE IF EXISTS `knowledge_base_article_knowledge_base_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_article_knowledge_base_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `knowledge_base_article_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge_base_category_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_KNOWLEDGE_BASE_ARTICLE_ID_KNOWLEDGE_BASE_CATEGORY_ID` (`knowledge_base_article_id`,`knowledge_base_category_id`),
  KEY `IDX_KNOWLEDGE_BASE_ARTICLE_ID` (`knowledge_base_article_id`),
  KEY `IDX_KNOWLEDGE_BASE_CATEGORY_ID` (`knowledge_base_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_article_knowledge_base_category`
--

LOCK TABLES `knowledge_base_article_knowledge_base_category` WRITE;
/*!40000 ALTER TABLE `knowledge_base_article_knowledge_base_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_article_knowledge_base_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_article_portal`
--

DROP TABLE IF EXISTS `knowledge_base_article_portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_article_portal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge_base_article_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ID_KNOWLEDGE_BASE_ARTICLE_ID` (`portal_id`,`knowledge_base_article_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_KNOWLEDGE_BASE_ARTICLE_ID` (`knowledge_base_article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_article_portal`
--

LOCK TABLES `knowledge_base_article_portal` WRITE;
/*!40000 ALTER TABLE `knowledge_base_article_portal` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_article_portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_category`
--

DROP TABLE IF EXISTS `knowledge_base_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_category` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_category`
--

LOCK TABLES `knowledge_base_category` WRITE;
/*!40000 ALTER TABLE `knowledge_base_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_category_path`
--

DROP TABLE IF EXISTS `knowledge_base_category_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_category_path` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_category_path`
--

LOCK TABLES `knowledge_base_category_path` WRITE;
/*!40000 ALTER TABLE `knowledge_base_category_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_category_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layout_record`
--

DROP TABLE IF EXISTS `layout_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `layout_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_NAME_LAYOUT_SET_ID` (`name`,`layout_set_id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layout_record`
--

LOCK TABLES `layout_record` WRITE;
/*!40000 ALTER TABLE `layout_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `layout_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layout_set`
--

DROP TABLE IF EXISTS `layout_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `layout_set` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `layout_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layout_set`
--

LOCK TABLES `layout_set` WRITE;
/*!40000 ALTER TABLE `layout_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `layout_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead`
--

DROP TABLE IF EXISTS `lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'New',
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_amount` double DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `do_not_call` tinyint(1) NOT NULL DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `converted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `account_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_amount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_opportunity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_FIRST_NAME` (`first_name`,`deleted`),
  KEY `IDX_NAME` (`first_name`,`last_name`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CREATED_AT_STATUS` (`created_at`,`status`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_ACCOUNT_ID` (`created_account_id`),
  KEY `IDX_CREATED_CONTACT_ID` (`created_contact_id`),
  KEY `IDX_CREATED_OPPORTUNITY_ID` (`created_opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead`
--

LOCK TABLES `lead` WRITE;
/*!40000 ALTER TABLE `lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_capture`
--

DROP TABLE IF EXISTS `lead_capture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_capture` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `subscribe_to_target_list` tinyint(1) NOT NULL DEFAULT 1,
  `subscribe_contact_to_target_list` tinyint(1) NOT NULL DEFAULT 1,
  `field_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '["firstName","lastName","emailAddress"]',
  `field_params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duplicate_check` tinyint(1) NOT NULL DEFAULT 1,
  `opt_in_confirmation` tinyint(1) NOT NULL DEFAULT 0,
  `opt_in_confirmation_lifetime` int(11) DEFAULT 48,
  `opt_in_confirmation_success_message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_lead_before_opt_in_confirmation` tinyint(1) NOT NULL DEFAULT 0,
  `skip_opt_in_confirmation_if_subscribed` tinyint(1) NOT NULL DEFAULT 0,
  `lead_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Web Site',
  `api_key` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `form_title` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_theme` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_text` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_success_text` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_success_redirect_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_language` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_frame_ancestors` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_captcha` tinyint(1) NOT NULL DEFAULT 0,
  `phone_number_country` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opt_in_confirmation_email_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`),
  KEY `IDX_OPT_IN_CONFIRMATION_EMAIL_TEMPLATE_ID` (`opt_in_confirmation_email_template_id`),
  KEY `IDX_TARGET_TEAM_ID` (`target_team_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_capture`
--

LOCK TABLES `lead_capture` WRITE;
/*!40000 ALTER TABLE `lead_capture` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_capture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_capture_log_record`
--

DROP TABLE IF EXISTS `lead_capture_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_capture_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `number` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_created` tinyint(1) NOT NULL DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `lead_capture_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_LEAD_CAPTURE_ID` (`lead_capture_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_capture_log_record`
--

LOCK TABLES `lead_capture_log_record` WRITE;
/*!40000 ALTER TABLE `lead_capture_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_capture_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_meeting`
--

DROP TABLE IF EXISTS `lead_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_meeting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_LEAD_ID_MEETING_ID` (`lead_id`,`meeting_id`),
  KEY `IDX_LEAD_ID` (`lead_id`),
  KEY `IDX_MEETING_ID` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_meeting`
--

LOCK TABLES `lead_meeting` WRITE;
/*!40000 ALTER TABLE `lead_meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_target_list`
--

DROP TABLE IF EXISTS `lead_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_target_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_LEAD_ID_TARGET_LIST_ID` (`lead_id`,`target_list_id`),
  KEY `IDX_LEAD_ID` (`lead_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_target_list`
--

LOCK TABLES `lead_target_list` WRITE;
/*!40000 ALTER TABLE `lead_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_action`
--

DROP TABLE IF EXISTS `mass_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_action` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `processed_count` int(11) DEFAULT NULL,
  `notify_on_finish` tinyint(1) NOT NULL DEFAULT 0,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_action`
--

LOCK TABLES `mass_action` WRITE;
/*!40000 ALTER TABLE `mass_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_email`
--

DROP TABLE IF EXISTS `mass_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_email` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `store_sent_emails` tinyint(1) NOT NULL DEFAULT 0,
  `opt_out_entirely` tinyint(1) NOT NULL DEFAULT 0,
  `from_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `email_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EMAIL_TEMPLATE_ID` (`email_template_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_email`
--

LOCK TABLES `mass_email` WRITE;
/*!40000 ALTER TABLE `mass_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_email_target_list`
--

DROP TABLE IF EXISTS `mass_email_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_email_target_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mass_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_MASS_EMAIL_ID_TARGET_LIST_ID` (`mass_email_id`,`target_list_id`),
  KEY `IDX_MASS_EMAIL_ID` (`mass_email_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_email_target_list`
--

LOCK TABLES `mass_email_target_list` WRITE;
/*!40000 ALTER TABLE `mass_email_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_email_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_email_target_list_excluding`
--

DROP TABLE IF EXISTS `mass_email_target_list_excluding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_email_target_list_excluding` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mass_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_MASS_EMAIL_ID_TARGET_LIST_ID` (`mass_email_id`,`target_list_id`),
  KEY `IDX_MASS_EMAIL_ID` (`mass_email_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_email_target_list_excluding`
--

LOCK TABLES `mass_email_target_list_excluding` WRITE;
/*!40000 ALTER TABLE `mass_email_target_list_excluding` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_email_target_list_excluding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting`
--

DROP TABLE IF EXISTS `meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planned',
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `is_all_day` tinyint(1) NOT NULL DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `join_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `external_service` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `date_start_date` date DEFAULT NULL,
  `date_end_date` date DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_UID` (`uid`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting`
--

LOCK TABLES `meeting` WRITE;
/*!40000 ALTER TABLE `meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_user`
--

DROP TABLE IF EXISTS `meeting_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_MEETING_ID` (`user_id`,`meeting_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_MEETING_ID` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_user`
--

LOCK TABLES `meeting_user` WRITE;
/*!40000 ALTER TABLE `meeting_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `meeting_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `next_number`
--

DROP TABLE IF EXISTS `next_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `next_number` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` int(11) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE_FIELD_NAME` (`entity_type`,`field_name`),
  KEY `IDX_ENTITY_TYPE` (`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `next_number`
--

LOCK TABLES `next_number` WRITE;
/*!40000 ALTER TABLE `next_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `next_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `note` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `post` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Post',
  `target_type` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `is_global` tinyint(1) NOT NULL DEFAULT 0,
  `is_internal` tinyint(1) NOT NULL DEFAULT 0,
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `super_parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `super_parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_NUMBER` (`created_by_id`,`number`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_TARGET_TYPE` (`target_type`),
  KEY `IDX_PARENT_ID` (`parent_id`),
  KEY `IDX_PARENT_TYPE` (`parent_type`),
  KEY `IDX_RELATED_ID` (`related_id`),
  KEY `IDX_RELATED_TYPE` (`related_type`),
  KEY `IDX_SUPER_PARENT_TYPE` (`super_parent_type`),
  KEY `IDX_SUPER_PARENT_ID` (`super_parent_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_RELATED` (`related_id`,`related_type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_SUPER_PARENT` (`super_parent_id`,`super_parent_type`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`post`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_portal`
--

DROP TABLE IF EXISTS `note_portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_portal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `note_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NOTE_ID_PORTAL_ID` (`note_id`,`portal_id`),
  KEY `IDX_NOTE_ID` (`note_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_portal`
--

LOCK TABLES `note_portal` WRITE;
/*!40000 ALTER TABLE `note_portal` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_team`
--

DROP TABLE IF EXISTS `note_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_team` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `note_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NOTE_ID_TEAM_ID` (`note_id`,`team_id`),
  KEY `IDX_NOTE_ID` (`note_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_team`
--

LOCK TABLES `note_team` WRITE;
/*!40000 ALTER TABLE `note_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_user`
--

DROP TABLE IF EXISTS `note_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `note_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NOTE_ID_USER_ID` (`note_id`,`user_id`),
  KEY `IDX_NOTE_ID` (`note_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_user`
--

LOCK TABLES `note_user` WRITE;
/*!40000 ALTER TABLE `note_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `number` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `email_is_processed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_USER` (`user_id`,`number`),
  KEY `IDX_USER_ID_READ_RELATED_PARENT_TYPE` (`user_id`,`deleted`,`read`,`related_parent_type`),
  KEY `IDX_ACTION_ID` (`action_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_RELATED` (`related_id`,`related_type`),
  KEY `IDX_RELATED_PARENT` (`related_parent_id`,`related_parent_type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_account`
--

DROP TABLE IF EXISTS `o_auth_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_account` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `access_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refresh_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `provider_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PROVIDER_ID` (`provider_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_account`
--

LOCK TABLES `o_auth_account` WRITE;
/*!40000 ALTER TABLE `o_auth_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_provider`
--

DROP TABLE IF EXISTS `o_auth_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_provider` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `client_id` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorization_endpoint` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_endpoint` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorization_prompt` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorization_params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scope_separator` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_provider`
--

LOCK TABLES `o_auth_provider` WRITE;
/*!40000 ALTER TABLE `o_auth_provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity`
--

DROP TABLE IF EXISTS `opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `amount` double DEFAULT NULL,
  `stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Prospecting',
  `last_stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `probability` int(11) DEFAULT NULL,
  `lead_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `close_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `amount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_STAGE` (`stage`,`deleted`),
  KEY `IDX_LAST_STAGE` (`last_stage`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CREATED_AT_STAGE` (`created_at`,`stage`),
  KEY `IDX_ASSIGNED_USER_STAGE` (`assigned_user_id`,`stage`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity`
--

LOCK TABLES `opportunity` WRITE;
/*!40000 ALTER TABLE `opportunity` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_change_request`
--

DROP TABLE IF EXISTS `password_change_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_change_request` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `request_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_REQUEST_ID` (`request_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_change_request`
--

LOCK TABLES `password_change_request` WRITE;
/*!40000 ALTER TABLE `password_change_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_change_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone_number`
--

DROP TABLE IF EXISTS `phone_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_number` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numeric` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invalid` tinyint(1) NOT NULL DEFAULT 0,
  `opt_out` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_NUMERIC` (`numeric`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone_number`
--

LOCK TABLES `phone_number` WRITE;
/*!40000 ALTER TABLE `phone_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `phone_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pipeline`
--

DROP TABLE IF EXISTS `pipeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pipeline` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `order` int(11) DEFAULT NULL,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` int(11) DEFAULT NULL,
  `is_available_for_all` tinyint(1) NOT NULL DEFAULT 1,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE_STATUS` (`entity_type`,`status`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pipeline`
--

LOCK TABLES `pipeline` WRITE;
/*!40000 ALTER TABLE `pipeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `pipeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pipeline_stage`
--

DROP TABLE IF EXISTS `pipeline_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pipeline_stage` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `order` int(11) DEFAULT NULL,
  `mapped_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `pipeline_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PIPELINE_ID` (`pipeline_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pipeline_stage`
--

LOCK TABLES `pipeline_stage` WRITE;
/*!40000 ALTER TABLE `pipeline_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `pipeline_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal`
--

DROP TABLE IF EXISTS `portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `custom_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `tab_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quick_create_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `application_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_zone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `week_start` int(11) DEFAULT -1,
  `default_currency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_layout` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashlets_options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token_lifetime` double DEFAULT NULL,
  `auth_token_max_idle_time` double DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `logo_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_logo_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authentication_provider_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CUSTOM_ID` (`custom_id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`),
  KEY `IDX_AUTHENTICATION_PROVIDER_ID` (`authentication_provider_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal`
--

LOCK TABLES `portal` WRITE;
/*!40000 ALTER TABLE `portal` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_portal_role`
--

DROP TABLE IF EXISTS `portal_portal_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_portal_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ID_PORTAL_ROLE_ID` (`portal_id`,`portal_role_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_PORTAL_ROLE_ID` (`portal_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_portal_role`
--

LOCK TABLES `portal_portal_role` WRITE;
/*!40000 ALTER TABLE `portal_portal_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_portal_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_role`
--

DROP TABLE IF EXISTS `portal_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_role` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `export_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `mass_update_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_role`
--

LOCK TABLES `portal_role` WRITE;
/*!40000 ALTER TABLE `portal_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_role_user`
--

DROP TABLE IF EXISTS `portal_role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_role_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `portal_role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ROLE_ID_USER_ID` (`portal_role_id`,`user_id`),
  KEY `IDX_PORTAL_ROLE_ID` (`portal_role_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_role_user`
--

LOCK TABLES `portal_role_user` WRITE;
/*!40000 ALTER TABLE `portal_role_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_user`
--

DROP TABLE IF EXISTS `portal_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ID_USER_ID` (`portal_id`,`user_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_user`
--

LOCK TABLES `portal_user` WRITE;
/*!40000 ALTER TABLE `portal_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `preferences` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferences`
--

LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;
/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminder`
--

DROP TABLE IF EXISTS `reminder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `remind_at` datetime DEFAULT NULL,
  `start_at` datetime DEFAULT NULL,
  `type` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Popup',
  `seconds` int(11) DEFAULT 0,
  `is_submitted` tinyint(1) NOT NULL DEFAULT 0,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_REMIND_AT` (`remind_at`),
  KEY `IDX_START_AT` (`start_at`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminder`
--

LOCK TABLES `reminder` WRITE;
/*!40000 ALTER TABLE `reminder` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `assignment_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `user_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `message_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `portal_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `group_email_account_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `export_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `mass_update_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `data_privacy_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `follower_management_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `audit_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `mention_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `user_calendar_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `lock_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_team`
--

DROP TABLE IF EXISTS `role_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_team` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ROLE_ID_TEAM_ID` (`role_id`,`team_id`),
  KEY `IDX_ROLE_ID` (`role_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_team`
--

LOCK TABLES `role_team` WRITE;
/*!40000 ALTER TABLE `role_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ROLE_ID_USER_ID` (`role_id`,`user_id`),
  KEY `IDX_ROLE_ID` (`role_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_job`
--

DROP TABLE IF EXISTS `scheduled_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_job` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `job` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `scheduling` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `is_internal` tinyint(1) NOT NULL DEFAULT 0,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_job`
--

LOCK TABLES `scheduled_job` WRITE;
/*!40000 ALTER TABLE `scheduled_job` DISABLE KEYS */;
INSERT INTO `scheduled_job` VALUES
('69deb20ccb6fe02a5','Submit Popup Reminders',0,'SubmitPopupReminders','Active','* * * * *','2026-04-14 22:14:01','2026-04-14 21:30:52','2026-04-14 21:30:52',1,NULL,NULL),
('69deb20ccce1ad361','Process Job Group',0,'ProcessJobGroup','Active','* * * * *',NULL,'2026-04-14 21:30:52','2026-04-14 21:30:52',1,NULL,NULL),
('69deb20ccd7429e61','Process Job Queue q0',0,'ProcessJobQueueQ0','Active','* * * * *','2026-04-14 22:14:01','2026-04-14 21:30:52','2026-04-14 21:30:52',1,NULL,NULL),
('69deb20cce715fc29','Process Job Queue q1',0,'ProcessJobQueueQ1','Active','*/1 * * * *','2026-04-14 22:14:01','2026-04-14 21:30:52','2026-04-14 21:30:52',1,NULL,NULL),
('69deb20ccf068606a','Process Job Queue e0',0,'ProcessJobQueueE0','Active','* * * * *','2026-04-14 22:14:01','2026-04-14 21:30:52','2026-04-14 21:30:52',1,NULL,NULL),
('69deb20ccfca76e52','Dummy',0,'Dummy','Active','1 */12 * * *','2026-04-14 21:33:01','2026-04-14 21:30:52','2026-04-14 21:30:52',1,NULL,NULL),
('69deb20cd06ae2058','Check for New Version',0,'CheckNewVersion','Active','15 5 * * *',NULL,'2026-04-14 21:30:52','2026-04-14 21:30:52',1,NULL,NULL),
('69deb20cd1354293d','Check for New Versions of Installed Extensions',0,'CheckNewExtensionVersion','Active','25 5 * * *',NULL,'2026-04-14 21:30:52','2026-04-14 21:30:52',1,NULL,NULL),
('69deb20cd1cfc824e','Sync Currency Rates',0,'SyncCurrencyRates','Active','2 0 * * *',NULL,'2026-04-14 21:30:52','2026-04-14 21:30:52',1,NULL,NULL),
('69deb2255ed442e5f','Check Group Email Accounts',0,'CheckInboundEmails','Active','*/2 * * * *',NULL,'2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL),
('69deb2255f70a7f66','Check Personal Email Accounts',0,'CheckEmailAccounts','Active','*/1 * * * *',NULL,'2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL),
('69deb2255fe8dfb55','Send Email Reminders',0,'SendEmailReminders','Active','*/2 * * * *','2026-04-14 22:14:01','2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL),
('69deb225605e2291c','Send Email Notifications',0,'SendEmailNotifications','Active','*/2 * * * *','2026-04-14 22:14:01','2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL),
('69deb22560e095554','Clean-up',0,'Cleanup','Active','1 1 * * 0',NULL,'2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL),
('69deb22562da4c5df','Send Mass Emails',0,'ProcessMassEmail','Active','10,30,50 * * * *','2026-04-14 22:10:01','2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL),
('69deb2256424d2207','Auth Token Control',0,'AuthTokenControl','Active','*/6 * * * *','2026-04-14 22:12:01','2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL),
('69deb22565663a129','Control Knowledge Base Article Status',0,'ControlKnowledgeBaseArticleStatus','Active','10 1 * * *',NULL,'2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL),
('69deb22566a130762','Process Webhook Queue',0,'ProcessWebhookQueue','Active','*/2 * * * *','2026-04-14 22:14:01','2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL),
('69deb225672074885','Send Scheduled Emails',0,'SendScheduledEmails','Active','*/10 * * * *','2026-04-14 22:10:01','2026-04-14 21:31:17','2026-04-14 21:31:17',0,'system',NULL);
/*!40000 ALTER TABLE `scheduled_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_job_log_record`
--

DROP TABLE IF EXISTS `scheduled_job_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_job_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `execution_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `scheduled_job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_SCHEDULED_JOB_ID_EXECUTION_TIME` (`scheduled_job_id`,`execution_time`),
  KEY `IDX_SCHEDULED_JOB_ID` (`scheduled_job_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_job_log_record`
--

LOCK TABLES `scheduled_job_log_record` WRITE;
/*!40000 ALTER TABLE `scheduled_job_log_record` DISABLE KEYS */;
INSERT INTO `scheduled_job_log_record` VALUES
('69deb28d9be9853e4','Dummy',0,'Success','2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20ccfca76e52',NULL,NULL),
('69deb28d9d95936dd','Submit Popup Reminders',0,'Success','2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb28d9fcc2de2e','Process Job Queue q0',0,'Success','2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20ccd7429e61',NULL,NULL),
('69deb28da147eb722','Process Job Queue e0',0,'Success','2026-04-14 21:33:01','2026-04-14 21:33:01','69deb20ccf068606a',NULL,NULL),
('69deb2c9d008dc81b','Process Job Queue q1',0,'Success','2026-04-14 21:34:01','2026-04-14 21:34:01','69deb20cce715fc29',NULL,NULL),
('69deb2c9d238a51c5','Send Email Reminders',0,'Success','2026-04-14 21:34:01','2026-04-14 21:34:01','69deb2255fe8dfb55',NULL,NULL),
('69deb2c9d54ece350','Send Email Notifications',0,'Success','2026-04-14 21:34:01','2026-04-14 21:34:01','69deb225605e2291c',NULL,NULL),
('69deb2c9d89483a3b','Process Webhook Queue',0,'Success','2026-04-14 21:34:01','2026-04-14 21:34:01','69deb22566a130762',NULL,NULL),
('69deb2c9da2233ad0','Submit Popup Reminders',0,'Success','2026-04-14 21:34:01','2026-04-14 21:34:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb2c9dc867471e','Process Job Queue q0',0,'Success','2026-04-14 21:34:01','2026-04-14 21:34:01','69deb20ccd7429e61',NULL,NULL),
('69deb2c9de5968b46','Process Job Queue e0',0,'Success','2026-04-14 21:34:01','2026-04-14 21:34:01','69deb20ccf068606a',NULL,NULL),
('69deb3060f08790f2','Process Job Queue q1',0,'Success','2026-04-14 21:35:02','2026-04-14 21:35:02','69deb20cce715fc29',NULL,NULL),
('69deb30611042ed9f','Submit Popup Reminders',0,'Success','2026-04-14 21:35:02','2026-04-14 21:35:02','69deb20ccb6fe02a5',NULL,NULL),
('69deb30614ddd4649','Process Job Queue q0',0,'Success','2026-04-14 21:35:02','2026-04-14 21:35:02','69deb20ccd7429e61',NULL,NULL),
('69deb3061a851ac9f','Process Job Queue e0',0,'Success','2026-04-14 21:35:02','2026-04-14 21:35:02','69deb20ccf068606a',NULL,NULL),
('69deb341468ae9760','Auth Token Control',0,'Success','2026-04-14 21:36:01','2026-04-14 21:36:01','69deb2256424d2207',NULL,NULL),
('69deb34148ea9e8e2','Send Email Reminders',0,'Success','2026-04-14 21:36:01','2026-04-14 21:36:01','69deb2255fe8dfb55',NULL,NULL),
('69deb3414b6aa19cb','Send Email Notifications',0,'Success','2026-04-14 21:36:01','2026-04-14 21:36:01','69deb225605e2291c',NULL,NULL),
('69deb3414e0771992','Process Webhook Queue',0,'Success','2026-04-14 21:36:01','2026-04-14 21:36:01','69deb22566a130762',NULL,NULL),
('69deb3414fdcae3a0','Process Job Queue q1',0,'Success','2026-04-14 21:36:01','2026-04-14 21:36:01','69deb20cce715fc29',NULL,NULL),
('69deb34151c3bf987','Submit Popup Reminders',0,'Success','2026-04-14 21:36:01','2026-04-14 21:36:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb3415394d8429','Process Job Queue q0',0,'Success','2026-04-14 21:36:01','2026-04-14 21:36:01','69deb20ccd7429e61',NULL,NULL),
('69deb34156504db02','Process Job Queue e0',0,'Success','2026-04-14 21:36:01','2026-04-14 21:36:01','69deb20ccf068606a',NULL,NULL),
('69deb37d773422615','Process Job Queue q1',0,'Success','2026-04-14 21:37:01','2026-04-14 21:37:01','69deb20cce715fc29',NULL,NULL),
('69deb37d79740c18d','Submit Popup Reminders',0,'Success','2026-04-14 21:37:01','2026-04-14 21:37:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb37d7ae2bb640','Process Job Queue q0',0,'Success','2026-04-14 21:37:01','2026-04-14 21:37:01','69deb20ccd7429e61',NULL,NULL),
('69deb37d7d1c7c93d','Process Job Queue e0',0,'Success','2026-04-14 21:37:01','2026-04-14 21:37:01','69deb20ccf068606a',NULL,NULL),
('69deb3b9a38ac238d','Send Email Reminders',0,'Success','2026-04-14 21:38:01','2026-04-14 21:38:01','69deb2255fe8dfb55',NULL,NULL),
('69deb3b9a629d566a','Send Email Notifications',0,'Success','2026-04-14 21:38:01','2026-04-14 21:38:01','69deb225605e2291c',NULL,NULL),
('69deb3b9a9434eb91','Process Webhook Queue',0,'Success','2026-04-14 21:38:01','2026-04-14 21:38:01','69deb22566a130762',NULL,NULL),
('69deb3b9aad9a2536','Process Job Queue q1',0,'Success','2026-04-14 21:38:01','2026-04-14 21:38:01','69deb20cce715fc29',NULL,NULL),
('69deb3b9ad21bbe8d','Submit Popup Reminders',0,'Success','2026-04-14 21:38:01','2026-04-14 21:38:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb3b9af15819dc','Process Job Queue q0',0,'Success','2026-04-14 21:38:01','2026-04-14 21:38:01','69deb20ccd7429e61',NULL,NULL),
('69deb3b9b1d0cebbe','Process Job Queue e0',0,'Success','2026-04-14 21:38:01','2026-04-14 21:38:01','69deb20ccf068606a',NULL,NULL),
('69deb3f5d4ed9ceff','Process Job Queue q1',0,'Success','2026-04-14 21:39:01','2026-04-14 21:39:01','69deb20cce715fc29',NULL,NULL),
('69deb3f5d72c12b47','Submit Popup Reminders',0,'Success','2026-04-14 21:39:01','2026-04-14 21:39:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb3f5d93f3158b','Process Job Queue q0',0,'Success','2026-04-14 21:39:01','2026-04-14 21:39:01','69deb20ccd7429e61',NULL,NULL),
('69deb3f5dad76e5b1','Process Job Queue e0',0,'Success','2026-04-14 21:39:01','2026-04-14 21:39:01','69deb20ccf068606a',NULL,NULL),
('69deb43217b45614d','Send Scheduled Emails',0,'Success','2026-04-14 21:40:02','2026-04-14 21:40:02','69deb225672074885',NULL,NULL),
('69deb4321b25586a6','Send Email Reminders',0,'Success','2026-04-14 21:40:02','2026-04-14 21:40:02','69deb2255fe8dfb55',NULL,NULL),
('69deb4321e1f42a51','Send Email Notifications',0,'Success','2026-04-14 21:40:02','2026-04-14 21:40:02','69deb225605e2291c',NULL,NULL),
('69deb4322229cb5d8','Process Webhook Queue',0,'Success','2026-04-14 21:40:02','2026-04-14 21:40:02','69deb22566a130762',NULL,NULL),
('69deb4322446a98c9','Process Job Queue q1',0,'Success','2026-04-14 21:40:02','2026-04-14 21:40:02','69deb20cce715fc29',NULL,NULL),
('69deb43226e982c3d','Submit Popup Reminders',0,'Success','2026-04-14 21:40:02','2026-04-14 21:40:02','69deb20ccb6fe02a5',NULL,NULL),
('69deb432293fae13f','Process Job Queue q0',0,'Success','2026-04-14 21:40:02','2026-04-14 21:40:02','69deb20ccd7429e61',NULL,NULL),
('69deb4322c15b1025','Process Job Queue e0',0,'Success','2026-04-14 21:40:02','2026-04-14 21:40:02','69deb20ccf068606a',NULL,NULL),
('69deb46d5b52bf7ad','Process Job Queue q1',0,'Success','2026-04-14 21:41:01','2026-04-14 21:41:01','69deb20cce715fc29',NULL,NULL),
('69deb46d5dbd2fabc','Submit Popup Reminders',0,'Success','2026-04-14 21:41:01','2026-04-14 21:41:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb46d5fd8de194','Process Job Queue q0',0,'Success','2026-04-14 21:41:01','2026-04-14 21:41:01','69deb20ccd7429e61',NULL,NULL),
('69deb46d6241ac878','Process Job Queue e0',0,'Success','2026-04-14 21:41:01','2026-04-14 21:41:01','69deb20ccf068606a',NULL,NULL),
('69deb4a9924a8f99f','Auth Token Control',0,'Success','2026-04-14 21:42:01','2026-04-14 21:42:01','69deb2256424d2207',NULL,NULL),
('69deb4a99450d1dae','Send Email Reminders',0,'Success','2026-04-14 21:42:01','2026-04-14 21:42:01','69deb2255fe8dfb55',NULL,NULL),
('69deb4a997d9a85e3','Send Email Notifications',0,'Success','2026-04-14 21:42:01','2026-04-14 21:42:01','69deb225605e2291c',NULL,NULL),
('69deb4a99ac8bf25b','Process Webhook Queue',0,'Success','2026-04-14 21:42:01','2026-04-14 21:42:01','69deb22566a130762',NULL,NULL),
('69deb4a99d535db3e','Process Job Queue q1',0,'Success','2026-04-14 21:42:01','2026-04-14 21:42:01','69deb20cce715fc29',NULL,NULL),
('69deb4a99f20743e6','Submit Popup Reminders',0,'Success','2026-04-14 21:42:01','2026-04-14 21:42:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb4a9a20c08bec','Process Job Queue q0',0,'Success','2026-04-14 21:42:01','2026-04-14 21:42:01','69deb20ccd7429e61',NULL,NULL),
('69deb4a9a3ddc1dc0','Process Job Queue e0',0,'Success','2026-04-14 21:42:01','2026-04-14 21:42:01','69deb20ccf068606a',NULL,NULL),
('69deb4e5cc5bdb17a','Process Job Queue q1',0,'Success','2026-04-14 21:43:01','2026-04-14 21:43:01','69deb20cce715fc29',NULL,NULL),
('69deb4e5d01a5a756','Submit Popup Reminders',0,'Success','2026-04-14 21:43:01','2026-04-14 21:43:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb4e5d25542544','Process Job Queue q0',0,'Success','2026-04-14 21:43:01','2026-04-14 21:43:01','69deb20ccd7429e61',NULL,NULL),
('69deb4e5d516a53f9','Process Job Queue e0',0,'Success','2026-04-14 21:43:01','2026-04-14 21:43:01','69deb20ccf068606a',NULL,NULL),
('69deb5221319d0a53','Send Email Reminders',0,'Success','2026-04-14 21:44:02','2026-04-14 21:44:02','69deb2255fe8dfb55',NULL,NULL),
('69deb5221892c87d6','Send Email Notifications',0,'Success','2026-04-14 21:44:02','2026-04-14 21:44:02','69deb225605e2291c',NULL,NULL),
('69deb5221b6ba34a8','Process Webhook Queue',0,'Success','2026-04-14 21:44:02','2026-04-14 21:44:02','69deb22566a130762',NULL,NULL),
('69deb5221e3b8189e','Process Job Queue q1',0,'Success','2026-04-14 21:44:02','2026-04-14 21:44:02','69deb20cce715fc29',NULL,NULL),
('69deb52220a1e5f53','Submit Popup Reminders',0,'Success','2026-04-14 21:44:02','2026-04-14 21:44:02','69deb20ccb6fe02a5',NULL,NULL),
('69deb52224438d8b5','Process Job Queue q0',0,'Success','2026-04-14 21:44:02','2026-04-14 21:44:02','69deb20ccd7429e61',NULL,NULL),
('69deb522267d25c99','Process Job Queue e0',0,'Success','2026-04-14 21:44:02','2026-04-14 21:44:02','69deb20ccf068606a',NULL,NULL),
('69deb55d4cc8d0519','Process Job Queue q1',0,'Success','2026-04-14 21:45:01','2026-04-14 21:45:01','69deb20cce715fc29',NULL,NULL),
('69deb55d4f83928e1','Submit Popup Reminders',0,'Success','2026-04-14 21:45:01','2026-04-14 21:45:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb55d51e7363c5','Process Job Queue q0',0,'Success','2026-04-14 21:45:01','2026-04-14 21:45:01','69deb20ccd7429e61',NULL,NULL),
('69deb55d54a50d21b','Process Job Queue e0',0,'Success','2026-04-14 21:45:01','2026-04-14 21:45:01','69deb20ccf068606a',NULL,NULL),
('69deb599a31c3b43b','Send Email Reminders',0,'Success','2026-04-14 21:46:01','2026-04-14 21:46:01','69deb2255fe8dfb55',NULL,NULL),
('69deb599a8fa22973','Send Email Notifications',0,'Success','2026-04-14 21:46:01','2026-04-14 21:46:01','69deb225605e2291c',NULL,NULL),
('69deb599ad4349e3c','Process Webhook Queue',0,'Success','2026-04-14 21:46:01','2026-04-14 21:46:01','69deb22566a130762',NULL,NULL),
('69deb599b13607a59','Process Job Queue q1',0,'Success','2026-04-14 21:46:01','2026-04-14 21:46:01','69deb20cce715fc29',NULL,NULL),
('69deb599b35d83907','Submit Popup Reminders',0,'Success','2026-04-14 21:46:01','2026-04-14 21:46:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb599b5d7a3be5','Process Job Queue q0',0,'Success','2026-04-14 21:46:01','2026-04-14 21:46:01','69deb20ccd7429e61',NULL,NULL),
('69deb599b8963986e','Process Job Queue e0',0,'Success','2026-04-14 21:46:01','2026-04-14 21:46:01','69deb20ccf068606a',NULL,NULL),
('69deb5d5da7464e9b','Process Job Queue q1',0,'Success','2026-04-14 21:47:01','2026-04-14 21:47:01','69deb20cce715fc29',NULL,NULL),
('69deb5d5dca219946','Submit Popup Reminders',0,'Success','2026-04-14 21:47:01','2026-04-14 21:47:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb5d5de4879584','Process Job Queue q0',0,'Success','2026-04-14 21:47:01','2026-04-14 21:47:01','69deb20ccd7429e61',NULL,NULL),
('69deb5d5e07965ad4','Process Job Queue e0',0,'Success','2026-04-14 21:47:01','2026-04-14 21:47:01','69deb20ccf068606a',NULL,NULL),
('69deb612125838a2f','Auth Token Control',0,'Success','2026-04-14 21:48:02','2026-04-14 21:48:02','69deb2256424d2207',NULL,NULL),
('69deb61215177dcb5','Send Email Reminders',0,'Success','2026-04-14 21:48:02','2026-04-14 21:48:02','69deb2255fe8dfb55',NULL,NULL),
('69deb6121815cac74','Send Email Notifications',0,'Success','2026-04-14 21:48:02','2026-04-14 21:48:02','69deb225605e2291c',NULL,NULL),
('69deb6121a207c156','Process Webhook Queue',0,'Success','2026-04-14 21:48:02','2026-04-14 21:48:02','69deb22566a130762',NULL,NULL),
('69deb6121bafb9013','Process Job Queue q1',0,'Success','2026-04-14 21:48:02','2026-04-14 21:48:02','69deb20cce715fc29',NULL,NULL),
('69deb6121e0f65f2f','Submit Popup Reminders',0,'Success','2026-04-14 21:48:02','2026-04-14 21:48:02','69deb20ccb6fe02a5',NULL,NULL),
('69deb6121ff5a2d7e','Process Job Queue q0',0,'Success','2026-04-14 21:48:02','2026-04-14 21:48:02','69deb20ccd7429e61',NULL,NULL),
('69deb61222b329a33','Process Job Queue e0',0,'Success','2026-04-14 21:48:02','2026-04-14 21:48:02','69deb20ccf068606a',NULL,NULL),
('69deb64d47cd6c364','Process Job Queue q1',0,'Success','2026-04-14 21:49:01','2026-04-14 21:49:01','69deb20cce715fc29',NULL,NULL),
('69deb64d49653b4bd','Submit Popup Reminders',0,'Success','2026-04-14 21:49:01','2026-04-14 21:49:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb64d4b72f3f70','Process Job Queue q0',0,'Success','2026-04-14 21:49:01','2026-04-14 21:49:01','69deb20ccd7429e61',NULL,NULL),
('69deb64d4d69fac05','Process Job Queue e0',0,'Success','2026-04-14 21:49:01','2026-04-14 21:49:01','69deb20ccf068606a',NULL,NULL),
('69deb68971110797d','Send Mass Emails',0,'Success','2026-04-14 21:50:01','2026-04-14 21:50:01','69deb22562da4c5df',NULL,NULL),
('69deb68975802bc5a','Send Scheduled Emails',0,'Success','2026-04-14 21:50:01','2026-04-14 21:50:01','69deb225672074885',NULL,NULL),
('69deb689770e49545','Send Email Reminders',0,'Success','2026-04-14 21:50:01','2026-04-14 21:50:01','69deb2255fe8dfb55',NULL,NULL),
('69deb68979736a1f7','Send Email Notifications',0,'Success','2026-04-14 21:50:01','2026-04-14 21:50:01','69deb225605e2291c',NULL,NULL),
('69deb6897b588cc34','Process Webhook Queue',0,'Success','2026-04-14 21:50:01','2026-04-14 21:50:01','69deb22566a130762',NULL,NULL),
('69deb6897d4d3a4d3','Process Job Queue q1',0,'Success','2026-04-14 21:50:01','2026-04-14 21:50:01','69deb20cce715fc29',NULL,NULL),
('69deb6897eab6741c','Submit Popup Reminders',0,'Success','2026-04-14 21:50:01','2026-04-14 21:50:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb68980b783c27','Process Job Queue q0',0,'Success','2026-04-14 21:50:01','2026-04-14 21:50:01','69deb20ccd7429e61',NULL,NULL),
('69deb68982e2553bd','Process Job Queue e0',0,'Success','2026-04-14 21:50:01','2026-04-14 21:50:01','69deb20ccf068606a',NULL,NULL),
('69deb6c5a88a6521a','Process Job Queue q1',0,'Success','2026-04-14 21:51:01','2026-04-14 21:51:01','69deb20cce715fc29',NULL,NULL),
('69deb6c5aa44c910e','Submit Popup Reminders',0,'Success','2026-04-14 21:51:01','2026-04-14 21:51:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb6c5ac7a95734','Process Job Queue q0',0,'Success','2026-04-14 21:51:01','2026-04-14 21:51:01','69deb20ccd7429e61',NULL,NULL),
('69deb6c5af96e0494','Process Job Queue e0',0,'Success','2026-04-14 21:51:01','2026-04-14 21:51:01','69deb20ccf068606a',NULL,NULL),
('69deb701d2ec8210c','Send Email Reminders',0,'Success','2026-04-14 21:52:01','2026-04-14 21:52:01','69deb2255fe8dfb55',NULL,NULL),
('69deb701d62b6a52c','Send Email Notifications',0,'Success','2026-04-14 21:52:01','2026-04-14 21:52:01','69deb225605e2291c',NULL,NULL),
('69deb701d8974d018','Process Webhook Queue',0,'Success','2026-04-14 21:52:01','2026-04-14 21:52:01','69deb22566a130762',NULL,NULL),
('69deb701daf9333fb','Process Job Queue q1',0,'Success','2026-04-14 21:52:01','2026-04-14 21:52:01','69deb20cce715fc29',NULL,NULL),
('69deb701dd5052851','Submit Popup Reminders',0,'Success','2026-04-14 21:52:01','2026-04-14 21:52:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb701e0ff3a8c9','Process Job Queue q0',0,'Success','2026-04-14 21:52:01','2026-04-14 21:52:01','69deb20ccd7429e61',NULL,NULL),
('69deb701e3c0545d8','Process Job Queue e0',0,'Success','2026-04-14 21:52:01','2026-04-14 21:52:01','69deb20ccf068606a',NULL,NULL),
('69deb73e194470103','Process Job Queue q1',0,'Success','2026-04-14 21:53:02','2026-04-14 21:53:02','69deb20cce715fc29',NULL,NULL),
('69deb73e1b28cc7ea','Submit Popup Reminders',0,'Success','2026-04-14 21:53:02','2026-04-14 21:53:02','69deb20ccb6fe02a5',NULL,NULL),
('69deb73e1d6e3f7c3','Process Job Queue q0',0,'Success','2026-04-14 21:53:02','2026-04-14 21:53:02','69deb20ccd7429e61',NULL,NULL),
('69deb73e1ef5637fe','Process Job Queue e0',0,'Success','2026-04-14 21:53:02','2026-04-14 21:53:02','69deb20ccf068606a',NULL,NULL),
('69deb77946783c3a7','Auth Token Control',0,'Success','2026-04-14 21:54:01','2026-04-14 21:54:01','69deb2256424d2207',NULL,NULL),
('69deb779482c45f8d','Send Email Reminders',0,'Success','2026-04-14 21:54:01','2026-04-14 21:54:01','69deb2255fe8dfb55',NULL,NULL),
('69deb7794c79bff05','Send Email Notifications',0,'Success','2026-04-14 21:54:01','2026-04-14 21:54:01','69deb225605e2291c',NULL,NULL),
('69deb7794f08a0ddb','Process Webhook Queue',0,'Success','2026-04-14 21:54:01','2026-04-14 21:54:01','69deb22566a130762',NULL,NULL),
('69deb7795159abbfa','Process Job Queue q1',0,'Success','2026-04-14 21:54:01','2026-04-14 21:54:01','69deb20cce715fc29',NULL,NULL),
('69deb77953ad60055','Submit Popup Reminders',0,'Success','2026-04-14 21:54:01','2026-04-14 21:54:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb779566ce8cab','Process Job Queue q0',0,'Success','2026-04-14 21:54:01','2026-04-14 21:54:01','69deb20ccd7429e61',NULL,NULL),
('69deb77958fe00422','Process Job Queue e0',0,'Success','2026-04-14 21:54:01','2026-04-14 21:54:01','69deb20ccf068606a',NULL,NULL),
('69deb7b5793be04a8','Process Job Queue q1',0,'Success','2026-04-14 21:55:01','2026-04-14 21:55:01','69deb20cce715fc29',NULL,NULL),
('69deb7b57b281ec99','Submit Popup Reminders',0,'Success','2026-04-14 21:55:01','2026-04-14 21:55:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb7b57c881c9e6','Process Job Queue q0',0,'Success','2026-04-14 21:55:01','2026-04-14 21:55:01','69deb20ccd7429e61',NULL,NULL),
('69deb7b57e88928a0','Process Job Queue e0',0,'Success','2026-04-14 21:55:01','2026-04-14 21:55:01','69deb20ccf068606a',NULL,NULL),
('69deb7f1a1fea2fa2','Send Email Reminders',0,'Success','2026-04-14 21:56:01','2026-04-14 21:56:01','69deb2255fe8dfb55',NULL,NULL),
('69deb7f1a4be5d865','Send Email Notifications',0,'Success','2026-04-14 21:56:01','2026-04-14 21:56:01','69deb225605e2291c',NULL,NULL),
('69deb7f1a6b333a60','Process Webhook Queue',0,'Success','2026-04-14 21:56:01','2026-04-14 21:56:01','69deb22566a130762',NULL,NULL),
('69deb7f1a8c589a71','Process Job Queue q1',0,'Success','2026-04-14 21:56:01','2026-04-14 21:56:01','69deb20cce715fc29',NULL,NULL),
('69deb7f1aa5289a0a','Submit Popup Reminders',0,'Success','2026-04-14 21:56:01','2026-04-14 21:56:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb7f1ace8552fc','Process Job Queue q0',0,'Success','2026-04-14 21:56:01','2026-04-14 21:56:01','69deb20ccd7429e61',NULL,NULL),
('69deb7f1afef8720a','Process Job Queue e0',0,'Success','2026-04-14 21:56:01','2026-04-14 21:56:01','69deb20ccf068606a',NULL,NULL),
('69deb82dd318df24a','Process Job Queue q1',0,'Success','2026-04-14 21:57:01','2026-04-14 21:57:01','69deb20cce715fc29',NULL,NULL),
('69deb82dd522c0b9f','Submit Popup Reminders',0,'Success','2026-04-14 21:57:01','2026-04-14 21:57:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb82dd728525f3','Process Job Queue q0',0,'Success','2026-04-14 21:57:01','2026-04-14 21:57:01','69deb20ccd7429e61',NULL,NULL),
('69deb82dd993fbbd6','Process Job Queue e0',0,'Success','2026-04-14 21:57:01','2026-04-14 21:57:01','69deb20ccf068606a',NULL,NULL),
('69deb86a0a9f91690','Send Email Reminders',0,'Success','2026-04-14 21:58:02','2026-04-14 21:58:02','69deb2255fe8dfb55',NULL,NULL),
('69deb86a0dfc36920','Send Email Notifications',0,'Success','2026-04-14 21:58:02','2026-04-14 21:58:02','69deb225605e2291c',NULL,NULL),
('69deb86a10aaacc51','Process Webhook Queue',0,'Success','2026-04-14 21:58:02','2026-04-14 21:58:02','69deb22566a130762',NULL,NULL),
('69deb86a126962e9f','Process Job Queue q1',0,'Success','2026-04-14 21:58:02','2026-04-14 21:58:02','69deb20cce715fc29',NULL,NULL),
('69deb86a14bff8114','Submit Popup Reminders',0,'Success','2026-04-14 21:58:02','2026-04-14 21:58:02','69deb20ccb6fe02a5',NULL,NULL),
('69deb86a16b3c09ff','Process Job Queue q0',0,'Success','2026-04-14 21:58:02','2026-04-14 21:58:02','69deb20ccd7429e61',NULL,NULL),
('69deb86a1a0812eb9','Process Job Queue e0',0,'Success','2026-04-14 21:58:02','2026-04-14 21:58:02','69deb20ccf068606a',NULL,NULL),
('69deb8a541ec3104d','Process Job Queue q1',0,'Success','2026-04-14 21:59:01','2026-04-14 21:59:01','69deb20cce715fc29',NULL,NULL),
('69deb8a5438f59aea','Submit Popup Reminders',0,'Success','2026-04-14 21:59:01','2026-04-14 21:59:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb8a5458995487','Process Job Queue q0',0,'Success','2026-04-14 21:59:01','2026-04-14 21:59:01','69deb20ccd7429e61',NULL,NULL),
('69deb8a5473c6273c','Process Job Queue e0',0,'Success','2026-04-14 21:59:01','2026-04-14 21:59:01','69deb20ccf068606a',NULL,NULL),
('69deb8e16f487aad6','Send Scheduled Emails',0,'Success','2026-04-14 22:00:01','2026-04-14 22:00:01','69deb225672074885',NULL,NULL),
('69deb8e171e244797','Auth Token Control',0,'Success','2026-04-14 22:00:01','2026-04-14 22:00:01','69deb2256424d2207',NULL,NULL),
('69deb8e1737a65931','Send Email Reminders',0,'Success','2026-04-14 22:00:01','2026-04-14 22:00:01','69deb2255fe8dfb55',NULL,NULL),
('69deb8e1765a236fc','Send Email Notifications',0,'Success','2026-04-14 22:00:01','2026-04-14 22:00:01','69deb225605e2291c',NULL,NULL),
('69deb8e1786e272b1','Process Webhook Queue',0,'Success','2026-04-14 22:00:01','2026-04-14 22:00:01','69deb22566a130762',NULL,NULL),
('69deb8e17be5e5285','Process Job Queue q1',0,'Success','2026-04-14 22:00:01','2026-04-14 22:00:01','69deb20cce715fc29',NULL,NULL),
('69deb8e17e4b65468','Submit Popup Reminders',0,'Success','2026-04-14 22:00:01','2026-04-14 22:00:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb8e1812a062d3','Process Job Queue q0',0,'Success','2026-04-14 22:00:01','2026-04-14 22:00:01','69deb20ccd7429e61',NULL,NULL),
('69deb8e1839b9c814','Process Job Queue e0',0,'Success','2026-04-14 22:00:01','2026-04-14 22:00:01','69deb20ccf068606a',NULL,NULL),
('69deb91da60cb5344','Process Job Queue q1',0,'Success','2026-04-14 22:01:01','2026-04-14 22:01:01','69deb20cce715fc29',NULL,NULL),
('69deb91da7d4ae8e4','Submit Popup Reminders',0,'Success','2026-04-14 22:01:01','2026-04-14 22:01:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb91da9f08c6f7','Process Job Queue q0',0,'Success','2026-04-14 22:01:01','2026-04-14 22:01:01','69deb20ccd7429e61',NULL,NULL),
('69deb91dab780520e','Process Job Queue e0',0,'Success','2026-04-14 22:01:01','2026-04-14 22:01:01','69deb20ccf068606a',NULL,NULL),
('69deb959cc259e6f0','Send Email Reminders',0,'Success','2026-04-14 22:02:01','2026-04-14 22:02:01','69deb2255fe8dfb55',NULL,NULL),
('69deb959cf0622df4','Send Email Notifications',0,'Success','2026-04-14 22:02:01','2026-04-14 22:02:01','69deb225605e2291c',NULL,NULL),
('69deb959d1020769a','Process Webhook Queue',0,'Success','2026-04-14 22:02:01','2026-04-14 22:02:01','69deb22566a130762',NULL,NULL),
('69deb959d2d6e2859','Process Job Queue q1',0,'Success','2026-04-14 22:02:01','2026-04-14 22:02:01','69deb20cce715fc29',NULL,NULL),
('69deb959d47e76126','Submit Popup Reminders',0,'Success','2026-04-14 22:02:01','2026-04-14 22:02:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb959d731c314a','Process Job Queue q0',0,'Success','2026-04-14 22:02:01','2026-04-14 22:02:01','69deb20ccd7429e61',NULL,NULL),
('69deb959dadc33c95','Process Job Queue e0',0,'Success','2026-04-14 22:02:01','2026-04-14 22:02:01','69deb20ccf068606a',NULL,NULL),
('69deb9961c6f99df3','Process Job Queue q1',0,'Success','2026-04-14 22:03:02','2026-04-14 22:03:02','69deb20cce715fc29',NULL,NULL),
('69deb9961ea94ef0c','Submit Popup Reminders',0,'Success','2026-04-14 22:03:02','2026-04-14 22:03:02','69deb20ccb6fe02a5',NULL,NULL),
('69deb996220b7fe5e','Process Job Queue q0',0,'Success','2026-04-14 22:03:02','2026-04-14 22:03:02','69deb20ccd7429e61',NULL,NULL),
('69deb9962548ab391','Process Job Queue e0',0,'Success','2026-04-14 22:03:02','2026-04-14 22:03:02','69deb20ccf068606a',NULL,NULL),
('69deb9d1500b2ae8f','Send Email Reminders',0,'Success','2026-04-14 22:04:01','2026-04-14 22:04:01','69deb2255fe8dfb55',NULL,NULL),
('69deb9d152f6d117e','Send Email Notifications',0,'Success','2026-04-14 22:04:01','2026-04-14 22:04:01','69deb225605e2291c',NULL,NULL),
('69deb9d1553eb378c','Process Webhook Queue',0,'Success','2026-04-14 22:04:01','2026-04-14 22:04:01','69deb22566a130762',NULL,NULL),
('69deb9d15747c5cb5','Process Job Queue q1',0,'Success','2026-04-14 22:04:01','2026-04-14 22:04:01','69deb20cce715fc29',NULL,NULL),
('69deb9d158df125d3','Submit Popup Reminders',0,'Success','2026-04-14 22:04:01','2026-04-14 22:04:01','69deb20ccb6fe02a5',NULL,NULL),
('69deb9d15af7d3317','Process Job Queue q0',0,'Success','2026-04-14 22:04:01','2026-04-14 22:04:01','69deb20ccd7429e61',NULL,NULL),
('69deb9d15d35837e8','Process Job Queue e0',0,'Success','2026-04-14 22:04:01','2026-04-14 22:04:01','69deb20ccf068606a',NULL,NULL),
('69deba0d8f25110b4','Process Job Queue q1',0,'Success','2026-04-14 22:05:01','2026-04-14 22:05:01','69deb20cce715fc29',NULL,NULL),
('69deba0d9299690f2','Submit Popup Reminders',0,'Success','2026-04-14 22:05:01','2026-04-14 22:05:01','69deb20ccb6fe02a5',NULL,NULL),
('69deba0d95ad7160d','Process Job Queue q0',0,'Success','2026-04-14 22:05:01','2026-04-14 22:05:01','69deb20ccd7429e61',NULL,NULL),
('69deba0d979c2b8b8','Process Job Queue e0',0,'Success','2026-04-14 22:05:01','2026-04-14 22:05:01','69deb20ccf068606a',NULL,NULL),
('69deba49d1e557b68','Auth Token Control',0,'Success','2026-04-14 22:06:01','2026-04-14 22:06:01','69deb2256424d2207',NULL,NULL),
('69deba49d578abdf9','Send Email Reminders',0,'Success','2026-04-14 22:06:01','2026-04-14 22:06:01','69deb2255fe8dfb55',NULL,NULL),
('69deba49d9919a386','Send Email Notifications',0,'Success','2026-04-14 22:06:01','2026-04-14 22:06:01','69deb225605e2291c',NULL,NULL),
('69deba49dfec28036','Process Webhook Queue',0,'Success','2026-04-14 22:06:01','2026-04-14 22:06:01','69deb22566a130762',NULL,NULL),
('69deba49e1be25983','Process Job Queue q1',0,'Success','2026-04-14 22:06:01','2026-04-14 22:06:01','69deb20cce715fc29',NULL,NULL),
('69deba49e45bd0f49','Submit Popup Reminders',0,'Success','2026-04-14 22:06:01','2026-04-14 22:06:01','69deb20ccb6fe02a5',NULL,NULL),
('69deba49e736c225b','Process Job Queue q0',0,'Success','2026-04-14 22:06:01','2026-04-14 22:06:01','69deb20ccd7429e61',NULL,NULL),
('69deba49e9d89f2b7','Process Job Queue e0',0,'Success','2026-04-14 22:06:01','2026-04-14 22:06:01','69deb20ccf068606a',NULL,NULL),
('69deba86237b206d6','Process Job Queue q1',0,'Success','2026-04-14 22:07:02','2026-04-14 22:07:02','69deb20cce715fc29',NULL,NULL),
('69deba86266840661','Submit Popup Reminders',0,'Success','2026-04-14 22:07:02','2026-04-14 22:07:02','69deb20ccb6fe02a5',NULL,NULL),
('69deba8628b4846e0','Process Job Queue q0',0,'Success','2026-04-14 22:07:02','2026-04-14 22:07:02','69deb20ccd7429e61',NULL,NULL),
('69deba862b08d7b86','Process Job Queue e0',0,'Success','2026-04-14 22:07:02','2026-04-14 22:07:02','69deb20ccf068606a',NULL,NULL),
('69debac157d722f5a','Send Email Reminders',0,'Success','2026-04-14 22:08:01','2026-04-14 22:08:01','69deb2255fe8dfb55',NULL,NULL),
('69debac15a9f2255e','Send Email Notifications',0,'Success','2026-04-14 22:08:01','2026-04-14 22:08:01','69deb225605e2291c',NULL,NULL),
('69debac15d5fa4f53','Process Webhook Queue',0,'Success','2026-04-14 22:08:01','2026-04-14 22:08:01','69deb22566a130762',NULL,NULL),
('69debac15efe5ea88','Process Job Queue q1',0,'Success','2026-04-14 22:08:01','2026-04-14 22:08:01','69deb20cce715fc29',NULL,NULL),
('69debac160b8a73fe','Submit Popup Reminders',0,'Success','2026-04-14 22:08:01','2026-04-14 22:08:01','69deb20ccb6fe02a5',NULL,NULL),
('69debac1638bd629c','Process Job Queue q0',0,'Success','2026-04-14 22:08:01','2026-04-14 22:08:01','69deb20ccd7429e61',NULL,NULL),
('69debac16641ce565','Process Job Queue e0',0,'Success','2026-04-14 22:08:01','2026-04-14 22:08:01','69deb20ccf068606a',NULL,NULL),
('69debafd8fe1735ad','Process Job Queue q1',0,'Success','2026-04-14 22:09:01','2026-04-14 22:09:01','69deb20cce715fc29',NULL,NULL),
('69debafd920c60fcd','Submit Popup Reminders',0,'Success','2026-04-14 22:09:01','2026-04-14 22:09:01','69deb20ccb6fe02a5',NULL,NULL),
('69debafd93a901e89','Process Job Queue q0',0,'Success','2026-04-14 22:09:01','2026-04-14 22:09:01','69deb20ccd7429e61',NULL,NULL),
('69debafd95b056cc6','Process Job Queue e0',0,'Success','2026-04-14 22:09:01','2026-04-14 22:09:01','69deb20ccf068606a',NULL,NULL),
('69debb39c7e89b9d1','Send Mass Emails',0,'Success','2026-04-14 22:10:01','2026-04-14 22:10:01','69deb22562da4c5df',NULL,NULL),
('69debb39cd814ad0a','Send Scheduled Emails',0,'Success','2026-04-14 22:10:01','2026-04-14 22:10:01','69deb225672074885',NULL,NULL),
('69debb39cfcc10f29','Send Email Reminders',0,'Success','2026-04-14 22:10:01','2026-04-14 22:10:01','69deb2255fe8dfb55',NULL,NULL),
('69debb39d30bdbb54','Send Email Notifications',0,'Success','2026-04-14 22:10:01','2026-04-14 22:10:01','69deb225605e2291c',NULL,NULL),
('69debb39d5f44f9bd','Process Webhook Queue',0,'Success','2026-04-14 22:10:01','2026-04-14 22:10:01','69deb22566a130762',NULL,NULL),
('69debb39d8c0406d2','Process Job Queue q1',0,'Success','2026-04-14 22:10:01','2026-04-14 22:10:01','69deb20cce715fc29',NULL,NULL),
('69debb39daff1ea4a','Submit Popup Reminders',0,'Success','2026-04-14 22:10:01','2026-04-14 22:10:01','69deb20ccb6fe02a5',NULL,NULL),
('69debb39debc9b13c','Process Job Queue q0',0,'Success','2026-04-14 22:10:01','2026-04-14 22:10:01','69deb20ccd7429e61',NULL,NULL),
('69debb39e0867fa87','Process Job Queue e0',0,'Success','2026-04-14 22:10:01','2026-04-14 22:10:01','69deb20ccf068606a',NULL,NULL),
('69debb761a701cd14','Process Job Queue q1',0,'Success','2026-04-14 22:11:02','2026-04-14 22:11:02','69deb20cce715fc29',NULL,NULL),
('69debb761c4f6269e','Submit Popup Reminders',0,'Success','2026-04-14 22:11:02','2026-04-14 22:11:02','69deb20ccb6fe02a5',NULL,NULL),
('69debb761e6fbb924','Process Job Queue q0',0,'Success','2026-04-14 22:11:02','2026-04-14 22:11:02','69deb20ccd7429e61',NULL,NULL),
('69debb7620bc2e762','Process Job Queue e0',0,'Success','2026-04-14 22:11:02','2026-04-14 22:11:02','69deb20ccf068606a',NULL,NULL),
('69debbb15b27aa881','Auth Token Control',0,'Success','2026-04-14 22:12:01','2026-04-14 22:12:01','69deb2256424d2207',NULL,NULL),
('69debbb15deeccf65','Send Email Reminders',0,'Success','2026-04-14 22:12:01','2026-04-14 22:12:01','69deb2255fe8dfb55',NULL,NULL),
('69debbb1615175f59','Send Email Notifications',0,'Success','2026-04-14 22:12:01','2026-04-14 22:12:01','69deb225605e2291c',NULL,NULL),
('69debbb16496e69f0','Process Webhook Queue',0,'Success','2026-04-14 22:12:01','2026-04-14 22:12:01','69deb22566a130762',NULL,NULL),
('69debbb167357f51a','Process Job Queue q1',0,'Success','2026-04-14 22:12:01','2026-04-14 22:12:01','69deb20cce715fc29',NULL,NULL),
('69debbb1691b57ef4','Submit Popup Reminders',0,'Success','2026-04-14 22:12:01','2026-04-14 22:12:01','69deb20ccb6fe02a5',NULL,NULL),
('69debbb16b9b27a07','Process Job Queue q0',0,'Success','2026-04-14 22:12:01','2026-04-14 22:12:01','69deb20ccd7429e61',NULL,NULL),
('69debbb16f44e6a48','Process Job Queue e0',0,'Success','2026-04-14 22:12:01','2026-04-14 22:12:01','69deb20ccf068606a',NULL,NULL),
('69debbed96c21bd49','Process Job Queue q1',0,'Success','2026-04-14 22:13:01','2026-04-14 22:13:01','69deb20cce715fc29',NULL,NULL),
('69debbed9868c031b','Submit Popup Reminders',0,'Success','2026-04-14 22:13:01','2026-04-14 22:13:01','69deb20ccb6fe02a5',NULL,NULL),
('69debbed9a776e227','Process Job Queue q0',0,'Success','2026-04-14 22:13:01','2026-04-14 22:13:01','69deb20ccd7429e61',NULL,NULL),
('69debbed9c1c09351','Process Job Queue e0',0,'Success','2026-04-14 22:13:01','2026-04-14 22:13:01','69deb20ccf068606a',NULL,NULL),
('69debc29c0e0b7470','Send Email Reminders',0,'Success','2026-04-14 22:14:01','2026-04-14 22:14:01','69deb2255fe8dfb55',NULL,NULL),
('69debc29c4b345ffd','Send Email Notifications',0,'Success','2026-04-14 22:14:01','2026-04-14 22:14:01','69deb225605e2291c',NULL,NULL),
('69debc29c6ce958cc','Process Webhook Queue',0,'Success','2026-04-14 22:14:01','2026-04-14 22:14:01','69deb22566a130762',NULL,NULL),
('69debc29c97c99d2e','Process Job Queue q1',0,'Success','2026-04-14 22:14:01','2026-04-14 22:14:01','69deb20cce715fc29',NULL,NULL),
('69debc29cc0d30be9','Submit Popup Reminders',0,'Success','2026-04-14 22:14:01','2026-04-14 22:14:01','69deb20ccb6fe02a5',NULL,NULL),
('69debc29ce6c3f592','Process Job Queue q0',0,'Success','2026-04-14 22:14:01','2026-04-14 22:14:01','69deb20ccd7429e61',NULL,NULL),
('69debc29d1962d4d5','Process Job Queue e0',0,'Success','2026-04-14 22:14:01','2026-04-14 22:14:01','69deb20ccf068606a',NULL,NULL);
/*!40000 ALTER TABLE `scheduled_job_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms`
--

DROP TABLE IF EXISTS `sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Archived',
  `date_sent` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `from_phone_number_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replied_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_SENT` (`date_sent`,`deleted`),
  KEY `IDX_DATE_SENT_STATUS` (`date_sent`,`status`,`deleted`),
  KEY `IDX_FROM_PHONE_NUMBER_ID` (`from_phone_number_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_REPLIED_ID` (`replied_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms`
--

LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_phone_number`
--

DROP TABLE IF EXISTS `sms_phone_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_phone_number` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sms_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_type` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_SMS_ID_PHONE_NUMBER_ID_ADDRESS_TYPE` (`sms_id`,`phone_number_id`,`address_type`),
  KEY `IDX_SMS_ID` (`sms_id`),
  KEY `IDX_PHONE_NUMBER_ID` (`phone_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_phone_number`
--

LOCK TABLES `sms_phone_number` WRITE;
/*!40000 ALTER TABLE `sms_phone_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_phone_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `star_subscription`
--

DROP TABLE IF EXISTS `star_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `star_subscription` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ENTITY` (`user_id`,`entity_id`,`entity_type`),
  KEY `IDX_USER_ENTITY_TYPE` (`user_id`,`entity_type`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `star_subscription`
--

LOCK TABLES `star_subscription` WRITE;
/*!40000 ALTER TABLE `star_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `star_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_subscription`
--

DROP TABLE IF EXISTS `stream_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_subscription` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `deleted` tinyint(1) DEFAULT 0,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_USER_ENTITY` (`user_id`,`entity_id`,`entity_type`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_subscription`
--

LOCK TABLES `stream_subscription` WRITE;
/*!40000 ALTER TABLE `stream_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `stream_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_data`
--

DROP TABLE IF EXISTS `system_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_data` (
  `id` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `last_password_recovery_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_data`
--

LOCK TABLES `system_data` WRITE;
/*!40000 ALTER TABLE `system_data` DISABLE KEYS */;
INSERT INTO `system_data` VALUES
('1',0,NULL);
/*!40000 ALTER TABLE `system_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target`
--

DROP TABLE IF EXISTS `target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `target` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `do_not_call` tinyint(1) NOT NULL DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FIRST_NAME` (`first_name`,`deleted`),
  KEY `IDX_NAME` (`first_name`,`last_name`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target`
--

LOCK TABLES `target` WRITE;
/*!40000 ALTER TABLE `target` DISABLE KEYS */;
/*!40000 ALTER TABLE `target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list`
--

DROP TABLE IF EXISTS `target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `category_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CATEGORY_ID` (`category_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list`
--

LOCK TABLES `target_list` WRITE;
/*!40000 ALTER TABLE `target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list_category`
--

DROP TABLE IF EXISTS `target_list_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list_category` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `order` int(11) DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list_category`
--

LOCK TABLES `target_list_category` WRITE;
/*!40000 ALTER TABLE `target_list_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list_category_path`
--

DROP TABLE IF EXISTS `target_list_category_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list_category_path` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list_category_path`
--

LOCK TABLES `target_list_category_path` WRITE;
/*!40000 ALTER TABLE `target_list_category_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list_category_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list_user`
--

DROP TABLE IF EXISTS `target_list_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint(1) DEFAULT 0,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_TARGET_LIST_ID` (`user_id`,`target_list_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list_user`
--

LOCK TABLES `target_list_user` WRITE;
/*!40000 ALTER TABLE `target_list_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Not Started',
  `priority` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Normal',
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `date_start_date` date DEFAULT NULL,
  `date_end_date` date DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint(20) DEFAULT NULL,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_END_STATUS` (`date_end`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_EMAIL_ID` (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task`
--

LOCK TABLES `task` WRITE;
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
/*!40000 ALTER TABLE `task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `position_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_calendar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`),
  KEY `IDX_WORKING_TIME_CALENDAR_ID` (`working_time_calendar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_user`
--

DROP TABLE IF EXISTS `team_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_TEAM_ID_USER_ID` (`team_id`,`user_id`),
  KEY `IDX_TEAM_ID` (`team_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_user`
--

LOCK TABLES `team_user` WRITE;
/*!40000 ALTER TABLE `team_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `template` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `header` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `left_margin` double DEFAULT 10,
  `right_margin` double DEFAULT 10,
  `top_margin` double DEFAULT 10,
  `bottom_margin` double DEFAULT 20,
  `print_footer` tinyint(1) NOT NULL DEFAULT 0,
  `print_header` tinyint(1) NOT NULL DEFAULT 0,
  `footer_position` double DEFAULT 10,
  `header_position` double DEFAULT 0,
  `style` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `page_orientation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Portrait',
  `page_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'A4',
  `page_width` double DEFAULT NULL,
  `page_height` double DEFAULT NULL,
  `font_face` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filename` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template`
--

LOCK TABLES `template` WRITE;
/*!40000 ALTER TABLE `template` DISABLE KEYS */;
/*!40000 ALTER TABLE `template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_factor_code`
--

DROP TABLE IF EXISTS `two_factor_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor_code` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts_left` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_USER_ID_METHOD` (`user_id`,`method`),
  KEY `IDX_USER_ID_METHOD_IS_ACTIVE` (`user_id`,`method`,`is_active`),
  KEY `IDX_USER_ID_METHOD_CREATED_AT` (`user_id`,`method`,`created_at`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor_code`
--

LOCK TABLES `two_factor_code` WRITE;
/*!40000 ALTER TABLE `two_factor_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unique_id`
--

DROP TABLE IF EXISTS `unique_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `unique_id` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `terminate_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unique_id`
--

LOCK TABLES `unique_id` WRITE;
/*!40000 ALTER TABLE `unique_id` DISABLE KEYS */;
/*!40000 ALTER TABLE `unique_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'regular',
  `password` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_method` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_color` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `default_team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_calendar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_NAME_DELETE_ID` (`user_name`,`delete_id`),
  KEY `IDX_USER_NAME` (`user_name`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_DEFAULT_TEAM_ID` (`default_team_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_DASHBOARD_TEMPLATE_ID` (`dashboard_template_id`),
  KEY `IDX_WORKING_TIME_CALENDAR_ID` (`working_time_calendar_id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES
('69deb215ad78dd7aa',0,'admin','admin','$2y$10$IJx7b85hLg.j3wefCWzZ3uJF.U/ihS8hJTbWK3QB9wc33i5nEoZhu',NULL,NULL,NULL,NULL,'Admin',1,NULL,NULL,NULL,'2026-04-14 21:31:01','2026-04-14 21:31:01',NULL,'0',NULL,NULL,NULL,'system',NULL,NULL,NULL),
('system',0,'system','system',NULL,NULL,NULL,NULL,NULL,'System',1,NULL,NULL,NULL,'2026-04-14 21:30:52','2026-04-14 21:30:52',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data`
--

DROP TABLE IF EXISTS `user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_data` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `auth2_f_a` tinyint(1) NOT NULL DEFAULT 0,
  `auth2_f_a_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth2_f_a_totp_secret` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth2_f_a_email_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data`
--

LOCK TABLES `user_data` WRITE;
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_reaction`
--

DROP TABLE IF EXISTS `user_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_reaction` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PARENT_USER_TYPE` (`parent_id`,`parent_type`,`user_id`,`type`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_reaction`
--

LOCK TABLES `user_reaction` WRITE;
/*!40000 ALTER TABLE `user_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_working_time_range`
--

DROP TABLE IF EXISTS `user_working_time_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_working_time_range` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_range_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_WORKING_TIME_RANGE_ID` (`user_id`,`working_time_range_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_WORKING_TIME_RANGE_ID` (`working_time_range_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_working_time_range`
--

LOCK TABLES `user_working_time_range` WRITE;
/*!40000 ALTER TABLE `user_working_time_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_working_time_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook`
--

DROP TABLE IF EXISTS `webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skip_own` tinyint(1) NOT NULL DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EVENT` (`event`),
  KEY `IDX_ENTITY_TYPE_TYPE` (`entity_type`,`type`),
  KEY `IDX_ENTITY_TYPE_FIELD` (`entity_type`,`field`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook`
--

LOCK TABLES `webhook` WRITE;
/*!40000 ALTER TABLE `webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_event_queue_item`
--

DROP TABLE IF EXISTS `webhook_event_queue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_event_queue_item` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `number` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_processed` tinyint(1) NOT NULL DEFAULT 0,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_TARGET` (`target_id`,`target_type`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_event_queue_item`
--

LOCK TABLES `webhook_event_queue_item` WRITE;
/*!40000 ALTER TABLE `webhook_event_queue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_event_queue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_queue_item`
--

DROP TABLE IF EXISTS `webhook_queue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_queue_item` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `number` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `processed_at` datetime DEFAULT NULL,
  `attempts` int(11) DEFAULT 0,
  `process_at` datetime DEFAULT NULL,
  `webhook_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_WEBHOOK_ID` (`webhook_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_queue_item`
--

LOCK TABLES `webhook_queue_item` WRITE;
/*!40000 ALTER TABLE `webhook_queue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_queue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_time_calendar`
--

DROP TABLE IF EXISTS `working_time_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_time_calendar` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_zone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '[["9:00","17:00"]]',
  `weekday0` tinyint(1) NOT NULL DEFAULT 0,
  `weekday1` tinyint(1) NOT NULL DEFAULT 1,
  `weekday2` tinyint(1) NOT NULL DEFAULT 1,
  `weekday3` tinyint(1) NOT NULL DEFAULT 1,
  `weekday4` tinyint(1) NOT NULL DEFAULT 1,
  `weekday5` tinyint(1) NOT NULL DEFAULT 1,
  `weekday6` tinyint(1) NOT NULL DEFAULT 0,
  `weekday0_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weekday1_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weekday2_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weekday3_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weekday4_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weekday5_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weekday6_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_time_calendar`
--

LOCK TABLES `working_time_calendar` WRITE;
/*!40000 ALTER TABLE `working_time_calendar` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_time_calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_time_calendar_working_time_range`
--

DROP TABLE IF EXISTS `working_time_calendar_working_time_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_time_calendar_working_time_range` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `working_time_calendar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_range_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_WORKING_TIME_CALENDAR_ID_WORKING_TIME_RANGE_ID` (`working_time_calendar_id`,`working_time_range_id`),
  KEY `IDX_WORKING_TIME_CALENDAR_ID` (`working_time_calendar_id`),
  KEY `IDX_WORKING_TIME_RANGE_ID` (`working_time_range_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_time_calendar_working_time_range`
--

LOCK TABLES `working_time_calendar_working_time_range` WRITE;
/*!40000 ALTER TABLE `working_time_calendar_working_time_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_time_calendar_working_time_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_time_range`
--

DROP TABLE IF EXISTS `working_time_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_time_range` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT 0,
  `time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `type` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Non-working',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_TYPE_RANGE` (`type`,`date_start`,`date_end`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_time_range`
--

LOCK TABLES `working_time_range` WRITE;
/*!40000 ALTER TABLE `working_time_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_time_range` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-15  4:14:14
